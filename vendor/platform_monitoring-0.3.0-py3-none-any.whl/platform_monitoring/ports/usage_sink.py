"""UsageSink Protocol — the usage-domain storage/query port."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol, runtime_checkable
from uuid import UUID

from platform_monitoring.usage.events import UsageEventBase
from platform_monitoring.usage.query_models import (
    ActorRow,
    CostBucket,
    ModelRow,
    StepBucket,
    ToolRow,
    UnpricedModel,
    UsageSummary,
)

Bucket = str  # "hour" | "day"


@runtime_checkable
class UsageSink(Protocol):
    """Durable store + read API for the usage telemetry domain."""

    async def write_usage_batch(self, events: Sequence[UsageEventBase]) -> None:
        ...

    async def llm_cost_series(
        self,
        *,
        org_id: UUID | None,
        since_ts: int,
        until_ts: int,
        bucket: Bucket,
    ) -> list[CostBucket]:
        ...

    async def llm_by_model(
        self,
        *,
        org_id: UUID | None,
        since_ts: int,
        until_ts: int,
    ) -> list[ModelRow]:
        ...

    async def cost_by_actor(
        self,
        *,
        since_ts: int,
        until_ts: int,
        top_n: int,
    ) -> list[ActorRow]:
        ...

    async def tool_top(
        self,
        *,
        since_ts: int,
        until_ts: int,
        top_n: int,
    ) -> list[ToolRow]:
        ...

    async def step_throughput(
        self,
        *,
        since_ts: int,
        until_ts: int,
        bucket: Bucket,
    ) -> list[StepBucket]:
        ...

    async def usage_summary(
        self,
        *,
        since_ts: int,
        until_ts: int,
    ) -> UsageSummary:
        ...

    async def unpriced_models(
        self,
        *,
        since_ts: int,
        until_ts: int,
    ) -> list[UnpricedModel]:
        ...


__all__ = ["UsageSink", "Bucket"]

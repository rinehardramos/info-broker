# src/platform_monitoring/usage/router.py
"""create_usage_router — admin-gated FastAPI router for the usage telemetry domain.

Mounted under /v3/monitoring/usage (the host app mounts the returned router on the
main monitoring router). Auth is provided by the injected admin_dependency — the
library does not check the return value.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query

from platform_monitoring.ports.usage_sink import UsageSink


def create_usage_router(
    *,
    admin_dependency: Any,
    sink: UsageSink,
    prefix: str = "/v3/monitoring/usage",
) -> APIRouter:
    """Factory for the admin-only usage analytics router.

    Args:
        admin_dependency: A FastAPI ``Depends(...)`` expression. The library does
            not check its return value — it just ensures the dep runs.
        sink: A UsageSink implementation (typically ClickHouseUsageSink).
        prefix: URL prefix for all routes.
    """
    router = APIRouter(prefix=prefix, tags=["monitoring-usage"])

    @router.get("/summary", dependencies=[admin_dependency])
    async def usage_summary(
        since: int = Query(..., description="Start epoch ms (inclusive)"),
        until: int = Query(..., description="End epoch ms (exclusive)"),
    ) -> Any:
        result = await sink.usage_summary(since_ts=since, until_ts=until)
        return result.model_dump()

    @router.get("/llm/cost-series", dependencies=[admin_dependency])
    async def llm_cost_series(
        since: int = Query(...),
        until: int = Query(...),
        bucket: str = Query(default="hour", pattern="^(hour|day)$"),
        org_id: UUID | None = Query(default=None),
    ) -> Any:
        # FastAPI validates org_id format on input → 422 on malformed UUID.
        rows = await sink.llm_cost_series(
            org_id=org_id, since_ts=since, until_ts=until, bucket=bucket
        )
        return [r.model_dump() for r in rows]

    @router.get("/llm/by-model", dependencies=[admin_dependency])
    async def llm_by_model(
        since: int = Query(...),
        until: int = Query(...),
        org_id: UUID | None = Query(default=None),
    ) -> Any:
        rows = await sink.llm_by_model(org_id=org_id, since_ts=since, until_ts=until)
        return [r.model_dump() for r in rows]

    @router.get("/llm/by-actor", dependencies=[admin_dependency])
    async def cost_by_actor(
        since: int = Query(...),
        until: int = Query(...),
        top: int = Query(default=20, ge=1, le=200),
    ) -> Any:
        rows = await sink.cost_by_actor(since_ts=since, until_ts=until, top_n=top)
        return [r.model_dump() for r in rows]

    @router.get("/llm/unpriced-models", dependencies=[admin_dependency])
    async def unpriced_models(
        since: int = Query(...),
        until: int = Query(...),
    ) -> Any:
        rows = await sink.unpriced_models(since_ts=since, until_ts=until)
        return [r.model_dump() for r in rows]

    @router.get("/tools/top", dependencies=[admin_dependency])
    async def tool_top(
        since: int = Query(...),
        until: int = Query(...),
        top: int = Query(default=20, ge=1, le=200),
    ) -> Any:
        rows = await sink.tool_top(since_ts=since, until_ts=until, top_n=top)
        return [r.model_dump() for r in rows]

    @router.get("/steps/throughput", dependencies=[admin_dependency])
    async def step_throughput(
        since: int = Query(...),
        until: int = Query(...),
        bucket: str = Query(default="hour", pattern="^(hour|day)$"),
    ) -> Any:
        rows = await sink.step_throughput(since_ts=since, until_ts=until, bucket=bucket)
        return [r.model_dump() for r in rows]

    return router


__all__ = ["create_usage_router"]

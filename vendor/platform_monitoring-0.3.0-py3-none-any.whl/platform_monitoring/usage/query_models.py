"""TS-mirrorable response shapes for the usage read API.

Rules:
- All timestamps are epoch-ms integers.
- Fractions (rates, hit rates) are 0.0–1.0 floats.
- Nullable fields use `X | None` with explicit defaults.
"""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class CostBucket(BaseModel):
    ts: int
    org_id: UUID | None = None
    model: str
    cost_usd: float
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    calls: int


class ModelRow(BaseModel):
    model: str
    provider: str
    calls: int
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    total_cost_usd: float
    unknown_cost_calls: int


class ActorRow(BaseModel):
    org_id: UUID | None = None
    user_id: UUID | None = None
    caller_identity: str | None = None
    calls: int
    total_cost_usd: float
    unknown_cost_calls: int


class ToolRow(BaseModel):
    tool_name: str
    calls: int
    errors: int
    error_rate: float
    p95_duration_ms: float | None = None


class StepBucket(BaseModel):
    ts: int
    node_type: str | None = None
    succeeded: int
    failed: int
    skipped: int
    p95_duration_ms: float | None = None


class UsageSummary(BaseModel):
    total_llm_calls: int
    total_cost_usd: float
    unknown_cost_calls: int
    total_input_tokens: int
    total_output_tokens: int
    cache_read_tokens: int
    cache_hit_rate: float
    total_tool_calls: int
    tool_errors: int
    total_step_runs: int
    step_failures: int


class UnpricedModel(BaseModel):
    model: str
    provider: str
    calls: int
    first_seen_ts: int
    last_seen_ts: int


__all__ = [
    "CostBucket",
    "ModelRow",
    "ActorRow",
    "ToolRow",
    "StepBucket",
    "UsageSummary",
    "UnpricedModel",
]

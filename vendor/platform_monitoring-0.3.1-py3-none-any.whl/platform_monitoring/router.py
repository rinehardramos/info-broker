# src/platform_monitoring/router.py
"""create_monitoring_router — auth-agnostic FastAPI router factory.

Phase 2: all stubs replaced with real implementations.
All HTTP endpoints are behind the injected admin_dependency.
WS /ws is ticket-authed (single-use token from GET /ws/ticket).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable

from fastapi import APIRouter, HTTPException, Query, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from platform_monitoring.models import Block, Rule
from platform_monitoring.ports.event_sink import get_event_sink
from platform_monitoring.ports.hot_store import get_hot_store
from platform_monitoring.query import QueryService
from platform_monitoring.query_models import (
    ActorSpec,
    ActorTypeFilter,
    GeoSpec,
    Granularity,
    OverviewSpec,
    RequestFilter,
    TimeseriesSpec,
    TopDimension,
    TopSpec,
)


class ThrottleBody(BaseModel):
    """Request body for PUT /throttle."""

    subject: str
    limit_per_min: int


log = logging.getLogger("platform_monitoring.router")

_WS_READ_COUNT = 20
_WS_BLOCK_MS = 1_000


def create_monitoring_router(
    *,
    admin_dependency: Any,
    query_service: QueryService | None = None,
    mcp_stats_provider: Callable[[], Any] | None = None,
    prefix: str = "/v3/monitoring",
) -> APIRouter:
    """Factory for the admin-only monitoring router.

    Args:
        admin_dependency: A FastAPI ``Depends(...)`` expression supplied by the host.
            The library does not check its return value — it just ensures the dep runs.
        query_service: Pre-built QueryService. If None, falls back to the registered
            EventSink + HotStore at request time (useful when registries are set up
            after router creation).
        mcp_stats_provider: Optional async callable ``() -> Any`` that returns MCP
            tool stats from the host's existing data source. If None, /mcp returns 501.
        prefix: URL prefix for all routes (default ``/v3/monitoring``).
    """
    router = APIRouter(prefix=prefix, tags=["monitoring"])

    def _qs() -> QueryService:
        if query_service is not None:
            return query_service
        from platform_monitoring.ports.event_sink import get_event_sink

        return QueryService(sink=get_event_sink(), hot=get_hot_store())

    # ── Read-only analytics (Phase 1, unchanged) ──────────────────────────────

    @router.get("/overview", dependencies=[admin_dependency])
    async def overview(
        from_ts: int = Query(default=..., description="Epoch ms start"),
        to_ts: int = Query(default=..., description="Epoch ms end"),
    ) -> Any:
        spec = OverviewSpec(from_ts=from_ts, to_ts=to_ts)
        result = await _qs().overview(spec)
        return result.model_dump()

    @router.get("/timeseries", dependencies=[admin_dependency])
    async def timeseries(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        granularity: Granularity = Query(default="minute"),
        actor_type: ActorTypeFilter | None = Query(default=None),
        country: str | None = Query(default=None),
        route: str | None = Query(default=None),
    ) -> Any:
        spec = TimeseriesSpec(
            from_ts=from_ts,
            to_ts=to_ts,
            granularity=granularity,
            actor_type=actor_type,
            country=country,
            route=route,
        )
        points = await _qs().timeseries(spec)
        return [p.model_dump() for p in points]

    @router.get("/top", dependencies=[admin_dependency])
    async def top(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        dimension: TopDimension = Query(default="ip"),
        limit: int = Query(default=20, ge=1, le=500),
        actor_type: ActorTypeFilter | None = Query(default=None),
    ) -> Any:
        spec = TopSpec(
            from_ts=from_ts, to_ts=to_ts, dimension=dimension, limit=limit, actor_type=actor_type
        )
        rows = await _qs().top(spec)
        return [r.model_dump() for r in rows]

    @router.get("/geo", dependencies=[admin_dependency])
    async def geo(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        limit: int = Query(default=200, ge=1, le=1000),
    ) -> Any:
        spec = GeoSpec(from_ts=from_ts, to_ts=to_ts, limit=limit)
        buckets = await _qs().geo(spec)
        return [b.model_dump() for b in buckets]

    # Every row includes request_id (for troubleshooting — see MEMORY.md feedback)
    @router.get("/requests", dependencies=[admin_dependency])
    async def requests(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        actor_type: ActorTypeFilter | None = Query(default=None),
        country: str | None = Query(default=None),
        route: str | None = Query(default=None),
        ip: str | None = Query(default=None),
        status: int | None = Query(default=None),
        limit: int = Query(default=100, ge=1, le=1000),
        offset: int = Query(default=0, ge=0),
    ) -> Any:
        filt = RequestFilter(
            from_ts=from_ts,
            to_ts=to_ts,
            actor_type=actor_type,
            country=country,
            route=route,
            ip=ip,
            status=status,
            limit=limit,
            offset=offset,
        )
        page = await _qs().requests(filt)
        return page.model_dump()

    @router.get("/actors/{actor_id}", dependencies=[admin_dependency])
    async def actor(
        actor_id: str,
        actor_type: ActorTypeFilter = Query(...),
        from_ts: int = Query(...),
        to_ts: int = Query(...),
    ) -> Any:
        spec = ActorSpec(actor_type=actor_type, actor_id=actor_id, from_ts=from_ts, to_ts=to_ts)
        summary = await _qs().actor(spec)
        return summary.model_dump()

    @router.get("/mcp", dependencies=[admin_dependency])
    async def mcp() -> Any:
        if mcp_stats_provider is None:
            raise HTTPException(
                status_code=501,
                detail="mcp_stats_provider not configured. "
                "Pass mcp_stats_provider= to create_monitoring_router().",
            )
        return await mcp_stats_provider()

    # ── Phase-2: blocks ───────────────────────────────────────────────────────

    @router.get("/blocks", dependencies=[admin_dependency])
    async def list_blocks() -> Any:
        hot = get_hot_store()
        blocks = await hot.list_blocks()
        return [b.model_dump() for b in blocks]

    @router.post("/blocks", dependencies=[admin_dependency], status_code=201)
    async def add_block(block: Block) -> Any:
        hot = get_hot_store()
        await hot.add_block(block)
        # Audit trail — best-effort; never stops the response
        try:
            sink = get_event_sink()
            await sink.write_block_audit(block, action="manual_block")
        except Exception:
            log.debug("write_block_audit failed for manual block", exc_info=True)
        return block.model_dump()

    @router.delete(
        "/blocks/{subject_type}/{subject}", dependencies=[admin_dependency], status_code=204
    )
    async def remove_block(subject_type: str, subject: str) -> None:
        await get_hot_store().remove_block(subject_type, subject)

    # ── Phase-2: alerts ───────────────────────────────────────────────────────

    @router.get("/alerts", dependencies=[admin_dependency])
    async def list_alerts(
        status: str | None = Query(default=None),
        limit: int = Query(default=50, ge=1, le=500),
    ) -> Any:
        alerts = await get_hot_store().list_alerts(status=status, limit=limit)
        return [a.model_dump() for a in alerts]

    @router.post("/alerts/{alert_id}/ack", dependencies=[admin_dependency])
    async def ack_alert(alert_id: str) -> Any:
        hot = get_hot_store()
        alert = await hot.get_alert(alert_id)
        if alert is None:
            raise HTTPException(status_code=404, detail=f"Alert {alert_id} not found")
        await hot.set_alert_status(alert_id, "ack")
        return {"id": alert_id, "status": "ack"}

    @router.post("/alerts/{alert_id}/resolve", dependencies=[admin_dependency])
    async def resolve_alert(alert_id: str) -> Any:
        hot = get_hot_store()
        alert = await hot.get_alert(alert_id)
        if alert is None:
            raise HTTPException(status_code=404, detail=f"Alert {alert_id} not found")
        await hot.set_alert_status(alert_id, "resolved")
        return {"id": alert_id, "status": "resolved"}

    # ── Phase-2: rules ────────────────────────────────────────────────────────

    @router.get("/rules", dependencies=[admin_dependency])
    async def get_rules() -> Any:
        rules = await get_hot_store().get_rules()
        return [r.model_dump() for r in rules]

    @router.put("/rules", dependencies=[admin_dependency])
    async def put_rules(rules: list[Rule]) -> Any:
        await get_hot_store().put_rules(rules)
        return [r.model_dump() for r in rules]

    # ── Phase-2: settings (kill-switch + allowlist) ───────────────────────────

    @router.get("/settings", dependencies=[admin_dependency])
    async def get_settings() -> Any:
        hot = get_hot_store()
        return {
            "enforcement_enabled": await hot.enforcement_enabled(),
            "allowlist": await hot.get_allowlist(),
        }

    @router.put("/settings", dependencies=[admin_dependency])
    async def put_settings(body: dict[str, Any]) -> Any:
        hot = get_hot_store()
        if "enforcement_enabled" in body:
            await hot.set_enforcement_enabled(bool(body["enforcement_enabled"]))
        if "allowlist" in body:
            await hot.set_allowlist(list(body["allowlist"]))
        return {
            "enforcement_enabled": await hot.enforcement_enabled(),
            "allowlist": await hot.get_allowlist(),
        }

    # ── Phase-2: throttle overrides ───────────────────────────────────────────

    @router.get("/throttle", dependencies=[admin_dependency])
    async def list_throttles() -> Any:
        return await get_hot_store().list_throttles()

    @router.put("/throttle", dependencies=[admin_dependency])
    async def put_throttle(body: ThrottleBody) -> Any:
        await get_hot_store().set_throttle(body.subject, body.limit_per_min)
        return {"subject": body.subject, "limit_per_min": body.limit_per_min}

    @router.delete("/throttle/{subject}", dependencies=[admin_dependency], status_code=204)
    async def delete_throttle(subject: str) -> None:
        await get_hot_store().set_throttle(subject, None)

    # ── Phase-2: WS ticket ────────────────────────────────────────────────────

    @router.get("/ws/ticket", dependencies=[admin_dependency])
    async def ws_ticket() -> Any:
        token = await get_hot_store().issue_ws_ticket(ttl_s=30)
        return {"ticket": token}

    # ── Phase-2: WS live feed ─────────────────────────────────────────────────

    @router.websocket("/ws")
    async def ws_live_feed(websocket: WebSocket, ticket: str = Query(...)) -> None:
        hot = get_hot_store()
        valid = await hot.consume_ws_ticket(ticket)
        if not valid:
            await websocket.close(code=4401)
            return

        await websocket.accept()
        # Use "$" semantics: only deliver entries added AFTER this connection opens.
        # We resolve "$" to the current latest stream ID once at connect time so that
        # subsequent XREAD calls with a concrete ID work correctly (XREAD does not
        # accept "$" as last_id for blocking reads — only for XREAD COUNT without >).
        try:
            events_cursor = await hot.get_stream_latest_id(stream="events")
        except Exception:
            events_cursor = "0"
        try:
            alerts_cursor = await hot.get_stream_latest_id(stream="alerts")
        except Exception:
            alerts_cursor = "0"
        try:
            while True:
                # Events stream
                ev_frames = await hot.read_events_stream(
                    last_id=events_cursor, block_ms=_WS_BLOCK_MS, count=_WS_READ_COUNT
                )
                for entry_id, ev in ev_frames:
                    events_cursor = entry_id
                    await websocket.send_json({"type": "request", **ev.model_dump()})

                # Alerts stream
                al_frames = await hot.read_alerts_stream(
                    last_id=alerts_cursor, block_ms=0, count=_WS_READ_COUNT
                )
                for entry_id, al in al_frames:
                    alerts_cursor = entry_id
                    await websocket.send_json({"type": "alert", **al.model_dump()})

                await asyncio.sleep(0)  # yield to event loop
        except WebSocketDisconnect:
            log.debug("WS client disconnected")
        except Exception:
            log.warning("WS live feed error", exc_info=True)
            try:
                await websocket.close()
            except Exception:
                pass

    return router

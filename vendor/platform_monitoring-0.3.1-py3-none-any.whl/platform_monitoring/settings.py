from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MonitoringSettings(BaseSettings):
    """Environment-driven configuration for platform-monitoring."""

    model_config = SettingsConfigDict(extra="ignore", case_sensitive=False)

    enabled: bool = Field(default=True, alias="MONITORING_ENABLED")
    clickhouse_url: str = Field(alias="CLICKHOUSE_URL")
    monitoring_redis_url: str = Field(alias="MONITORING_REDIS_URL")
    clickhouse_database: str = Field(default="mon", alias="MON_CLICKHOUSE_DATABASE")
    raw_retention_days: int = Field(default=30, alias="MON_RAW_RETENTION_DAYS")
    stream_maxlen: int = Field(default=1_000_000, alias="MON_STREAM_MAXLEN")

    # ── Phase-2 ───────────────────────────────────────────────────────────────
    # "open" (default) = proceed on HotStore lookup error; "closed" = 503
    enforcement_fail_mode: str = Field(default="open", alias="MON_ENFORCEMENT_FAIL_MODE")
    # HMAC-signed webhook for alert delivery; omit to use LogOnlyDelivery
    alert_webhook_url: str | None = Field(default=None, alias="MON_ALERT_WEBHOOK_URL")
    alert_webhook_secret: str = Field(default="", alias="MON_ALERT_WEBHOOK_SECRET")

    # ── v0.3.0 Usage domain ───────────────────────────────────────────────────
    usage_stream_maxlen: int = Field(default=100_000, alias="MON_USAGE_STREAM_MAXLEN")
    usage_retention_days: int = Field(default=90, alias="MON_USAGE_RETENTION_DAYS")
    usage_consumer_name: str = Field(default="worker", alias="MON_USAGE_CONSUMER_NAME")

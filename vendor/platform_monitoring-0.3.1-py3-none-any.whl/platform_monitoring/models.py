# src/platform_monitoring/models.py
"""Phase-2 control-plane models: Block, Rule, Alert."""

from typing import Any, Literal

from pydantic import BaseModel


class Block(BaseModel):
    subject_type: Literal["ip", "user", "caller"]
    subject: str
    reason: str = ""
    mode: Literal["block", "throttle"] = "block"
    until: int | None = None  # epoch ms; None = permanent
    scope: str = "app"  # "app" now; "cloudflare" reserved
    sync_targets: list[str] = []  # reserved for CF sync
    source: Literal["manual", "rule"] = "manual"
    created_by: str = ""  # admin user id or rule id


class Rule(BaseModel):
    id: str
    name: str
    metric: Literal["requests", "errors", "auth_failures"] = "requests"
    subject_dim: Literal["ip", "user", "caller", "route"] = "ip"
    window_s: int = 60
    threshold: int
    comparator: Literal[">", ">="] = ">"
    action: Literal["alert", "block"] = "alert"
    auto_block_enabled: bool = False  # DORMANT by default — per-rule opt-in
    block_ttl_s: int = 900  # auto-blocks are always temporary
    severity: Literal["info", "warning", "critical"] = "warning"
    cooldown_s: int = 300
    enabled: bool = True


class Alert(BaseModel):
    id: str
    ts: int  # epoch ms
    rule_id: str
    severity: str
    subject_type: str
    subject: str
    summary: str
    details: dict[str, Any] = {}
    status: Literal["open", "ack", "resolved"] = "open"
    auto_action: str = ""  # "" | "blocked:<ttl>" | "block_skipped:allowlisted" | ...

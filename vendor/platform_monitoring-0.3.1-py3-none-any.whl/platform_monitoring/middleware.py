"""Pure-ASGI monitoring middleware — no BaseHTTPMiddleware buffering cost.

Per request:
  1. Resolve real client IP (CF-Connecting-IP → XFF beyond trusted hops → ASGI client)
  2. Resolve geo per-request: build CloudflareGeo from request CF headers, then fall back
     to an optional shared GeoLite2 resolver if CF geo has no country; if neither is
     configured, use CloudflareGeo alone (returns source="cloudflare" with null fields).
  3. Identify the actor (best-effort, never raises)
  4. Assign request_id; echo as X-Request-Id response header
  5. ── PHASE-2 ── denylist check: is_blocked → 403/429 (still emits event)
  6. Call the next ASGI app
  7. Fire-and-forget: emit MonitoringEvent to HotStore (Redis error → log + drop + serve)
"""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import time
import uuid
from collections.abc import Callable
from typing import Any

from starlette.types import ASGIApp, Receive, Scope, Send

from platform_monitoring.adapters.cloudflare_geo import CloudflareGeo
from platform_monitoring.adapters.composite_geo import CompositeGeo
from platform_monitoring.envelope import Geo, MonitoringEvent
from platform_monitoring.identity import identify_actor
from platform_monitoring.ports.geo_resolver import GeoResolver
from platform_monitoring.ports.hot_store import get_hot_store

log = logging.getLogger("platform_monitoring.middleware")

# ─────────────────────────────────────────────────────────────────────────────
# IP trust-chain helpers (tested in test_middleware_ip.py)
# ─────────────────────────────────────────────────────────────────────────────


def _in_trusted(ip_str: str, trusted: set[str]) -> bool:
    # Plain string match first (handles non-IP peer hostnames such as "testclient")
    if ip_str in trusted:
        return True
    try:
        addr = ipaddress.ip_address(ip_str)
        return any(addr in ipaddress.ip_network(cidr, strict=False) for cidr in trusted)
    except ValueError:
        return False


def resolve_client_ip(
    *,
    scope_client: tuple[str, int] | None,
    headers: dict[str, str],
    trusted_proxies: set[str],
) -> str | None:
    """Return the best-effort real client IP string, or None."""
    peer = scope_client[0] if scope_client else None
    peer_trusted = peer is not None and _in_trusted(peer, trusted_proxies)

    # ① CF-Connecting-IP — only trust if the ASGI peer is a known proxy
    cf_ip = headers.get("cf-connecting-ip")
    if cf_ip and peer_trusted:
        return cf_ip.strip()

    # ② X-Forwarded-For — walk right-to-left, skip trusted hops
    xff = headers.get("x-forwarded-for", "")
    if xff and peer_trusted:
        hops = [h.strip() for h in xff.split(",")]
        # rightmost trusted hops are infrastructure; leftmost untrusted is the client
        for ip in reversed(hops):
            if not _in_trusted(ip, trusted_proxies):
                return ip
        # all hops trusted → return leftmost (original sender)
        return hops[0]

    # ③ ASGI client
    return peer


# ─────────────────────────────────────────────────────────────────────────────
# Middleware
# ─────────────────────────────────────────────────────────────────────────────


class MonitoringMiddleware:
    """Mount outermost so every response — including 404s and exceptions — is
    observed. Configured with an optional JWT decoder callable for actor
    identification and the set of trusted proxy CIDRs."""

    def __init__(
        self,
        app: ASGIApp,
        *,
        geolite2_resolver: GeoResolver | None = None,
        jwt_decoder: Callable[[str], dict[str, Any]] | None = None,
        trusted_proxies: set[str] | None = None,
        enforcement_fail_mode: str = "open",  # "open" | "closed"
    ) -> None:
        self._app = app
        self._lite2 = geolite2_resolver
        self._jwt_decoder = jwt_decoder
        self._trusted = trusted_proxies or set()
        self._fail_mode = enforcement_fail_mode
        # Retain references to fire-and-forget emit tasks so they aren't
        # garbage-collected mid-flight (see Python asyncio.ensure_future docs).
        self._tasks: set[asyncio.Task[None]] = set()

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        # Phase-1 captures HTTP only. WebSocket/lifespan scopes pass through
        # untouched — recording a WS connection as an http.request row (with
        # method="" / status=0) would pollute the telemetry.
        if scope["type"] != "http":
            await self._app(scope, receive, send)
            return

        raw_headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        headers = {k.decode().lower(): v.decode() for k, v in raw_headers}

        client_ip = resolve_client_ip(
            scope_client=scope.get("client"),
            headers=headers,
            trusted_proxies=self._trusted,
        )

        # ── Geo (per-request: CF headers first, optional GeoLite2 fallback) ──
        try:
            cf = CloudflareGeo(headers=headers)
            resolver: GeoResolver = (
                CompositeGeo(cf_resolver=cf, lite2_resolver=self._lite2)
                if self._lite2 is not None
                else cf
            )
            geo = await resolver.resolve(client_ip or "")
        except Exception:
            log.debug("geo resolution failed", exc_info=True)
            geo = Geo(source="none")

        # ── Actor identity ────────────────────────────────────────────────────
        actor = await identify_actor(headers, jwt_decoder=self._jwt_decoder)

        # ── Request ID ────────────────────────────────────────────────────────
        request_id = str(uuid.uuid4())
        # Store on scope state so downstream handlers can read it
        if "state" not in scope:
            scope["state"] = {}
        scope["state"]["request_id"] = request_id

        # ── Phase-2: enforcement seam ─────────────────────────────────────────
        # Attempt is_blocked; fail-open or fail-closed per enforcement_fail_mode.
        block = None
        try:
            hot = get_hot_store()
            block = await hot.is_blocked(actor, client_ip)
        except Exception:
            if self._fail_mode == "closed":
                log.warning("enforcement check failed (fail-closed) — returning 503")
                await self._send_plain(send, 503, b"Service Unavailable", request_id=request_id)
                return
            log.debug("enforcement check failed (fail-open) — proceeding", exc_info=True)

        if block is not None:
            status_code = 429 if block.mode == "throttle" else 403
            event = MonitoringEvent(
                event_id=request_id,
                event_type="http.request",
                ts=int(time.time() * 1000),
                actor=actor,
                source_ip=client_ip,
                geo=geo,
                attrs={
                    "method": scope.get("method", ""),
                    "route": (scope.get("state") or {}).get(
                        "route_template", scope.get("path", "")
                    ),
                    "path": scope.get("path", ""),
                    "status": status_code,
                    "latency_ms": 0,
                    "resp_bytes": 0,
                    "user_agent": headers.get("user-agent", ""),
                    "referer": headers.get("referer", ""),
                    "was_blocked": 1 if block.mode == "block" else 0,
                    "was_rate_limited": 1 if block.mode == "throttle" else 0,
                    "block_reason": block.reason or block.source,
                },
            )
            task = asyncio.ensure_future(self._emit(event))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
            await self._send_plain(
                send,
                status_code,
                b"Forbidden" if status_code == 403 else b"Too Many Requests",
                request_id=request_id,
            )
            return

        # ── Phase-2: throttle-rate-override consumer ──────────────────────────
        # Only reached when block is None (not already blocked).
        # Honors the kill-switch and allowlist; fails open on error.
        throttle_429 = False
        try:
            hot = get_hot_store()
            if (
                client_ip is not None
                and await hot.enforcement_enabled()
                and not await hot.is_allowlisted(client_ip, actor)
            ):
                limit = await hot.get_throttle(client_ip)
                if limit is not None and await hot.window_count("ip", client_ip, 60) >= limit:
                    throttle_429 = True
        except Exception:
            if self._fail_mode == "closed":
                log.warning("throttle check failed (fail-closed) — returning 503")
                await self._send_plain(send, 503, b"Service Unavailable", request_id=request_id)
                return
            log.debug("throttle check failed (fail-open) — proceeding", exc_info=True)

        if throttle_429:
            event = MonitoringEvent(
                event_id=request_id,
                event_type="http.request",
                ts=int(time.time() * 1000),
                actor=actor,
                source_ip=client_ip,
                geo=geo,
                attrs={
                    "method": scope.get("method", ""),
                    "route": (scope.get("state") or {}).get(
                        "route_template", scope.get("path", "")
                    ),
                    "path": scope.get("path", ""),
                    "status": 429,
                    "latency_ms": 0,
                    "resp_bytes": 0,
                    "user_agent": headers.get("user-agent", ""),
                    "referer": headers.get("referer", ""),
                    "was_blocked": 0,
                    "was_rate_limited": 1,
                    "block_reason": "throttle:rate_exceeded",
                },
            )
            task = asyncio.ensure_future(self._emit(event))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
            await self._send_plain(send, 429, b"Too Many Requests", request_id=request_id)
            return

        # ── Wrap send to capture status + response size ───────────────────────
        response_started: dict[str, Any] = {}
        resp_bytes = 0

        async def _send(message: Any) -> None:
            nonlocal resp_bytes
            if message["type"] == "http.response.start":
                response_started["status"] = message.get("status", 0)
                # Inject X-Request-Id into response headers
                headers_out: list[tuple[bytes, bytes]] = list(message.get("headers", []))
                headers_out.append((b"x-request-id", request_id.encode()))
                message = {**message, "headers": headers_out}
            elif message["type"] == "http.response.body":
                resp_bytes += len(message.get("body", b""))
            await send(message)

        t0 = time.monotonic()
        try:
            await self._app(scope, receive, _send)
        finally:
            latency_ms = int((time.monotonic() - t0) * 1000)
            status = response_started.get("status", 0)
            method = scope.get("method", "")
            path = scope.get("path", "")
            # Use route template from scope state if set by a framework like FastAPI
            route = (scope.get("state") or {}).get("route_template", path)

            event = MonitoringEvent(
                event_id=request_id,
                event_type="http.request",
                ts=int(time.time() * 1000),
                actor=actor,
                source_ip=client_ip,
                geo=geo,
                attrs={
                    "method": method,
                    "route": route,
                    "path": path,
                    "status": status,
                    "latency_ms": latency_ms,
                    "resp_bytes": resp_bytes,
                    "user_agent": headers.get("user-agent", ""),
                    "referer": headers.get("referer", ""),
                    "was_blocked": 0,
                    "was_rate_limited": 0,
                    "block_reason": "",
                },
            )
            task = asyncio.ensure_future(self._emit(event))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    @staticmethod
    async def _send_plain(
        send: Send, status: int, body: bytes, *, request_id: str | None = None
    ) -> None:
        headers: list[tuple[bytes, bytes]] = [
            (b"content-type", b"text/plain"),
            (b"content-length", str(len(body)).encode()),
        ]
        if request_id is not None:
            headers.append((b"x-request-id", request_id.encode()))
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": headers,
            }
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})

    async def _emit(self, event: MonitoringEvent) -> None:
        try:
            await get_hot_store().emit(event)
        except Exception:
            log.warning("MonitoringMiddleware: emit failed — event dropped", exc_info=True)

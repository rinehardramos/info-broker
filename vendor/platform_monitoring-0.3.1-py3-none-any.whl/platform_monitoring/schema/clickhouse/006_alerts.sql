-- 006_alerts.sql
-- Alert history (append-only). Mutable live state lives in mon:alert:{{id}} Redis hash.
CREATE TABLE IF NOT EXISTS {db}.alerts (
    alert_id     String,
    ts           DateTime64(3),
    rule_id      String,
    severity     LowCardinality(String),
    subject_type LowCardinality(String),
    subject      String,
    summary      String,
    details      String,
    auto_action  String
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(ts)
ORDER BY (ts, rule_id, subject)
TTL toDateTime(ts) + INTERVAL 90 DAY DELETE
SETTINGS index_granularity = 8192;

-- Block audit trail (append-only). Active blocks live in mon:block:* Redis hashes.
CREATE TABLE IF NOT EXISTS {db}.block_audit (
    ts           DateTime64(3),
    subject_type LowCardinality(String),
    subject      String,
    mode         LowCardinality(String),
    reason       String,
    source       LowCardinality(String),
    created_by   String,
    until        Nullable(Int64),
    action       LowCardinality(String)
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(ts)
ORDER BY (ts, subject_type, subject)
TTL toDateTime(ts) + INTERVAL 90 DAY DELETE
SETTINGS index_granularity = 8192;

# src/platform_monitoring/alert_delivery.py
"""AlertDelivery port + WebhookDelivery + LogOnlyDelivery (spec §7)."""

from __future__ import annotations

import hashlib
import hmac
import logging
from typing import Protocol, runtime_checkable

import httpx

from platform_monitoring.models import Alert

log = logging.getLogger("platform_monitoring.alert_delivery")


def _compute_signature(body: bytes, secret: str) -> str:
    """Return HMAC-SHA256 signature header value: 'sha256=<hex>'."""
    digest = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


@runtime_checkable
class AlertDelivery(Protocol):
    """Deliver an alert to an external channel. Must never raise."""

    async def deliver(self, alert: Alert) -> None: ...


class LogOnlyDelivery:
    """Dev default: log the alert, no external delivery."""

    async def deliver(self, alert: Alert) -> None:
        log.info(
            "alert [%s] rule=%s subject=%s severity=%s: %s",
            alert.id,
            alert.rule_id,
            alert.subject,
            alert.severity,
            alert.summary,
        )


class WebhookDelivery:
    """HMAC-signed HTTP POST to MON_ALERT_WEBHOOK_URL. Fail-silent."""

    def __init__(self, url: str, secret: str = "") -> None:
        self._url = url
        self._secret = secret

    async def deliver(self, alert: Alert) -> None:
        try:
            body = alert.model_dump_json().encode()
            sig = _compute_signature(body, self._secret)
            async with httpx.AsyncClient() as client:
                await client.post(
                    self._url,
                    content=body,
                    headers={
                        "Content-Type": "application/json",
                        "X-Mon-Signature": sig,
                    },
                    timeout=5.0,
                )
        except Exception:
            log.warning("AlertDelivery webhook failed", exc_info=True)

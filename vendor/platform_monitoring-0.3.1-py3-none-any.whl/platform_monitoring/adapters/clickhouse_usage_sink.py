# src/platform_monitoring/adapters/clickhouse_usage_sink.py
"""ClickHouseUsageSink — extends ClickHouseSink with the UsageSink port.

Single class; one ClickHouse connection; implements both EventSink (HTTP requests)
and UsageSink (tool_call / step_run / llm_call).

All SQL uses _esc() from the parent class for injection safety.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import UUID

from platform_monitoring.adapters.clickhouse_sink import ClickHouseSink
from platform_monitoring.usage.events import (
    LlmCallEvent,
    StepRunEvent,
    ToolCallEvent,
    UsageEventBase,
)
from platform_monitoring.usage.query_models import (
    ActorRow,
    CostBucket,
    ModelRow,
    StepBucket,
    TimeseriesPoint,
    ToolRow,
    UnpricedModel,
    UsageSummary,
)

_USAGE_SCHEMA_DIR = (
    Path(__file__).resolve().parent.parent / "usage" / "schema" / "clickhouse"
)

_TOOL_CALL_COLUMNS = [
    "event_id", "ts", "user_id", "org_id", "caller_identity",
    "run_id", "session_id", "node_id",
    "tool_name", "node_type", "status", "duration_ms", "result_count", "error_kind",
]

_STEP_RUN_COLUMNS = [
    "event_id", "ts", "user_id", "org_id", "caller_identity",
    "run_id", "session_id", "node_id",
    "node_type", "status", "item_count", "duration_ms", "error_kind",
]

_LLM_CALL_COLUMNS = [
    "event_id", "ts", "user_id", "org_id", "caller_identity",
    "run_id", "session_id", "node_id",
    "model", "provider", "status",
    "input_tokens", "output_tokens", "cache_creation_tokens", "cache_read_tokens",
    "duration_ms", "num_turns", "phase",
    "total_cost_usd", "cost_source", "pricing_id",
]


def _ms_to_dt(ts_ms: int) -> datetime:
    return datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)


def _opt_uuid(v: UUID | None) -> str | None:
    return str(v) if v is not None else None


def _tool_row(ev: ToolCallEvent) -> list[Any]:
    return [
        str(ev.event_id),
        _ms_to_dt(ev.ts),
        _opt_uuid(ev.actor.user_id),
        _opt_uuid(ev.actor.org_id),
        ev.actor.caller_identity,
        _opt_uuid(ev.run_id),
        _opt_uuid(ev.session_id),
        _opt_uuid(ev.node_id),
        ev.tool_name,
        ev.node_type,
        ev.status,
        ev.duration_ms,
        ev.result_count,
        ev.error_kind,
    ]


def _step_row(ev: StepRunEvent) -> list[Any]:
    return [
        str(ev.event_id),
        _ms_to_dt(ev.ts),
        _opt_uuid(ev.actor.user_id),
        _opt_uuid(ev.actor.org_id),
        ev.actor.caller_identity,
        _opt_uuid(ev.run_id),
        _opt_uuid(ev.session_id),
        _opt_uuid(ev.node_id),
        ev.node_type,
        ev.status,
        ev.item_count,
        ev.duration_ms,
        ev.error_kind,
    ]


def _llm_row(ev: LlmCallEvent) -> list[Any]:
    return [
        str(ev.event_id),
        _ms_to_dt(ev.ts),
        _opt_uuid(ev.actor.user_id),
        _opt_uuid(ev.actor.org_id),
        ev.actor.caller_identity,
        _opt_uuid(ev.run_id),
        _opt_uuid(ev.session_id),
        _opt_uuid(ev.node_id),
        ev.model,
        ev.provider,
        ev.status,
        ev.input_tokens,
        ev.output_tokens,
        ev.cache_creation_tokens,
        ev.cache_read_tokens,
        ev.duration_ms,
        ev.num_turns,
        ev.phase,
        ev.total_cost_usd,
        ev.cost_source,
        _opt_uuid(ev.pricing_id),
    ]


class ClickHouseUsageSink(ClickHouseSink):
    """Extends ClickHouseSink with the UsageSink port for the usage domain."""

    def __init__(
        self,
        url: str,
        *,
        database: str = "mon",
        raw_retention_days: int = 30,
        usage_retention_days: int = 90,
    ) -> None:
        super().__init__(url, database=database, raw_retention_days=raw_retention_days)
        self._usage_retention = usage_retention_days
        # Separate client for usage writes to avoid concurrent-session errors when
        # the IngestionWorker and UsageIngestionWorker run concurrently in
        # asyncio.gather and both call self._client.insert via asyncio.to_thread.
        from urllib.parse import urlsplit as _urlsplit
        import clickhouse_connect as _cc
        _parts = _urlsplit(url)
        self._usage_client = _cc.get_client(
            host=_parts.hostname or "localhost",
            port=_parts.port or 8123,
            username=_parts.username or "default",
            password=_parts.password or "",
            database="default",
        )

    async def bootstrap_usage_schema(self) -> None:
        """Create usage tables idempotently (CREATE TABLE IF NOT EXISTS)."""
        for path in sorted(_USAGE_SCHEMA_DIR.glob("*.sql")):
            text = path.read_text().format(
                db=self._db,
                usage_retention_days=self._usage_retention,
            )
            for statement in (s.strip() for s in text.split(";")):
                if any(
                    line.strip() and not line.strip().startswith("--")
                    for line in statement.splitlines()
                ):
                    await self._command(statement)

    # ── Write ─────────────────────────────────────────────────────────────────

    async def write_usage_batch(self, events: Sequence[UsageEventBase]) -> None:
        """Route events by kind and INSERT into the appropriate CH table.

        **Failure semantics — best-effort per-table, not atomic.** The three
        kinds are written in three separate INSERTs (CH MergeTree has no
        cross-table atomicity). If the tool_calls INSERT succeeds but the
        step_runs INSERT raises, the tool events are committed and the
        exception propagates with step + llm events un-written. The upstream
        Redis-stream consumer (worker) provides at-least-once retry on the
        whole batch, so the practical guarantee is "every event lands
        eventually, with possible per-table duplicates" — duplicates are
        keyed by ``event_id`` and can be deduped at read time if needed.
        """
        if not events:
            return
        tool_rows: list[list[Any]] = []
        step_rows: list[list[Any]] = []
        llm_rows: list[list[Any]] = []
        for ev in events:
            if isinstance(ev, ToolCallEvent):
                tool_rows.append(_tool_row(ev))
            elif isinstance(ev, StepRunEvent):
                step_rows.append(_step_row(ev))
            elif isinstance(ev, LlmCallEvent):
                llm_rows.append(_llm_row(ev))
        if tool_rows:
            await asyncio.to_thread(
                self._usage_client.insert,
                f"{self._db}.tool_calls",
                tool_rows,
                column_names=_TOOL_CALL_COLUMNS,
            )
        if step_rows:
            await asyncio.to_thread(
                self._usage_client.insert,
                f"{self._db}.step_runs",
                step_rows,
                column_names=_STEP_RUN_COLUMNS,
            )
        if llm_rows:
            await asyncio.to_thread(
                self._usage_client.insert,
                f"{self._db}.llm_calls",
                llm_rows,
                column_names=_LLM_CALL_COLUMNS,
            )

    # ── Read ──────────────────────────────────────────────────────────────────

    def _ts_where(self, since_ts: int, until_ts: int) -> str:
        """Build the time-range WHERE fragment used by every read method.

        Returns a SQL snippet that filters the ``ts`` column (every usage
        table uses the same column name and same DateTime64(3,'UTC') type),
        so no per-table dispatch is needed.
        """
        return (
            f"ts >= fromUnixTimestamp64Milli({int(since_ts)}) "
            f"AND ts < fromUnixTimestamp64Milli({int(until_ts)})"
        )

    def _bucket_fn(self, bucket: str) -> str:
        return {"hour": "toStartOfHour", "day": "toStartOfDay"}.get(bucket, "toStartOfHour")

    async def llm_cost_series(
        self,
        *,
        org_id: UUID | None,
        since_ts: int,
        until_ts: int,
        bucket: str,
    ) -> list[CostBucket]:
        where = self._ts_where(since_ts, until_ts)
        if org_id is not None:
            where += f" AND org_id = '{self._esc(str(org_id))}'"
        fn = self._bucket_fn(bucket)
        rows = await self._query(
            f"SELECT toUnixTimestamp({fn}(ts)) * 1000 AS ts_bucket, "
            f"org_id, model, "
            f"sum(coalesce(total_cost_usd, 0)) AS cost_usd, "
            f"sum(input_tokens) AS inp, sum(output_tokens) AS out, "
            f"sum(cache_read_tokens) AS cr, count() AS calls "
            f"FROM {self._db}.llm_calls WHERE {where} "
            f"GROUP BY ts_bucket, org_id, model ORDER BY ts_bucket"
        )
        return [
            CostBucket(
                ts=int(r[0]),
                org_id=UUID(str(r[1])) if r[1] else None,
                model=str(r[2]),
                cost_usd=float(r[3]),
                input_tokens=int(r[4]),
                output_tokens=int(r[5]),
                cache_read_tokens=int(r[6]),
                calls=int(r[7]),
            )
            for r in rows
        ]

    async def llm_by_model(
        self,
        *,
        org_id: UUID | None,
        since_ts: int,
        until_ts: int,
    ) -> list[ModelRow]:
        where = self._ts_where(since_ts, until_ts)
        if org_id is not None:
            where += f" AND org_id = '{self._esc(str(org_id))}'"
        rows = await self._query(
            f"SELECT model, provider, count() AS calls, "
            f"sum(input_tokens), sum(output_tokens), sum(cache_read_tokens), "
            f"sum(coalesce(total_cost_usd, 0)) AS total_cost, "
            f"countIf(total_cost_usd IS NULL) AS unknown_cost_calls "
            f"FROM {self._db}.llm_calls WHERE {where} "
            f"GROUP BY model, provider ORDER BY total_cost DESC"
        )
        return [
            ModelRow(
                model=str(r[0]),
                provider=str(r[1]),
                calls=int(r[2]),
                input_tokens=int(r[3]),
                output_tokens=int(r[4]),
                cache_read_tokens=int(r[5]),
                total_cost_usd=float(r[6]),
                unknown_cost_calls=int(r[7]),
            )
            for r in rows
        ]

    async def cost_by_actor(
        self,
        *,
        since_ts: int,
        until_ts: int,
        top_n: int,
    ) -> list[ActorRow]:
        where = self._ts_where(since_ts, until_ts)
        rows = await self._query(
            f"SELECT org_id, user_id, caller_identity, count() AS calls, "
            f"sum(coalesce(total_cost_usd, 0)) AS total_cost, "
            f"countIf(total_cost_usd IS NULL) AS unknown_cost_calls "
            f"FROM {self._db}.llm_calls WHERE {where} "
            f"GROUP BY org_id, user_id, caller_identity "
            f"ORDER BY total_cost DESC LIMIT {int(top_n)}"
        )
        return [
            ActorRow(
                org_id=UUID(str(r[0])) if r[0] else None,
                user_id=UUID(str(r[1])) if r[1] else None,
                caller_identity=str(r[2]) if r[2] else None,
                calls=int(r[3]),
                total_cost_usd=float(r[4]),
                unknown_cost_calls=int(r[5]),
            )
            for r in rows
        ]

    async def tool_top(
        self,
        *,
        since_ts: int,
        until_ts: int,
        top_n: int,
    ) -> list[ToolRow]:
        where = self._ts_where(since_ts, until_ts)
        rows = await self._query(
            f"SELECT tool_name, count() AS calls, countIf(status='error') AS errors, "
            f"quantile(0.95)(duration_ms) AS p95 "
            f"FROM {self._db}.tool_calls WHERE {where} "
            f"GROUP BY tool_name ORDER BY calls DESC LIMIT {int(top_n)}"
        )
        return [
            ToolRow(
                tool_name=str(r[0]),
                calls=int(r[1]),
                errors=int(r[2]),
                error_rate=int(r[2]) / int(r[1]) if int(r[1]) else 0.0,
                p95_duration_ms=float(r[3]) if r[3] is not None else None,
            )
            for r in rows
        ]

    async def step_throughput(
        self,
        *,
        since_ts: int,
        until_ts: int,
        bucket: str,
    ) -> list[StepBucket]:
        where = self._ts_where(since_ts, until_ts)
        fn = self._bucket_fn(bucket)
        rows = await self._query(
            f"SELECT toUnixTimestamp({fn}(ts)) * 1000 AS ts_bucket, "
            f"node_type, "
            f"countIf(status='succeeded') AS succeeded, "
            f"countIf(status='failed') AS failed, "
            f"countIf(status='skipped') AS skipped, "
            f"quantile(0.95)(duration_ms) AS p95 "
            f"FROM {self._db}.step_runs WHERE {where} "
            f"GROUP BY ts_bucket, node_type ORDER BY ts_bucket"
        )
        return [
            StepBucket(
                ts=int(r[0]),
                node_type=str(r[1]) if r[1] else None,
                succeeded=int(r[2]),
                failed=int(r[3]),
                skipped=int(r[4]),
                p95_duration_ms=float(r[5]) if r[5] is not None else None,
            )
            for r in rows
        ]

    async def usage_summary(
        self,
        *,
        since_ts: int,
        until_ts: int,
    ) -> UsageSummary:
        tc_where = self._ts_where(since_ts, until_ts)
        sr_where = self._ts_where(since_ts, until_ts)
        lc_where = self._ts_where(since_ts, until_ts)

        tc_row = (
            await self._query(
                f"SELECT count(), countIf(status='error') "
                f"FROM {self._db}.tool_calls WHERE {tc_where}"
            )
        )[0]
        sr_row = (
            await self._query(
                f"SELECT count(), countIf(status='failed') "
                f"FROM {self._db}.step_runs WHERE {sr_where}"
            )
        )[0]
        lc_row = (
            await self._query(
                f"SELECT count(), sum(coalesce(total_cost_usd, 0)), "
                f"countIf(total_cost_usd IS NULL), "
                f"sum(input_tokens), sum(output_tokens), sum(cache_read_tokens) "
                f"FROM {self._db}.llm_calls WHERE {lc_where}"
            )
        )[0]

        total_input = int(lc_row[3])
        cache_read = int(lc_row[5])
        denom = total_input + cache_read
        hit_rate = cache_read / denom if denom else 0.0

        return UsageSummary(
            total_llm_calls=int(lc_row[0]),
            total_cost_usd=float(lc_row[1]),
            unknown_cost_calls=int(lc_row[2]),
            total_input_tokens=total_input,
            total_output_tokens=int(lc_row[4]),
            cache_read_tokens=cache_read,
            cache_hit_rate=hit_rate,
            total_tool_calls=int(tc_row[0]),
            tool_errors=int(tc_row[1]),
            total_step_runs=int(sr_row[0]),
            step_failures=int(sr_row[1]),
        )

    async def unpriced_models(
        self,
        *,
        since_ts: int,
        until_ts: int,
    ) -> list[UnpricedModel]:
        where = self._ts_where(since_ts, until_ts)
        rows = await self._query(
            f"SELECT model, provider, count() AS calls, "
            f"toUnixTimestamp64Milli(min(ts)) AS first_seen, "
            f"toUnixTimestamp64Milli(max(ts)) AS last_seen "
            f"FROM {self._db}.llm_calls "
            f"WHERE {where} AND cost_source = 'unknown_model' "
            f"GROUP BY model, provider ORDER BY calls DESC"
        )
        return [
            UnpricedModel(
                model=str(r[0]),
                provider=str(r[1]),
                calls=int(r[2]),
                first_seen_ts=int(r[3]),
                last_seen_ts=int(r[4]),
            )
            for r in rows
        ]

    async def tools_timeseries(
        self,
        *,
        since_ts: int,
        until_ts: int,
        bucket: str,
    ) -> list[TimeseriesPoint]:
        """Time-bucketed count of tool_call events."""
        where = self._ts_where(since_ts, until_ts)
        fn = self._bucket_fn(bucket)
        rows = await self._query(
            f"SELECT toUnixTimestamp({fn}(ts)) * 1000 AS ts_bucket, count() AS cnt "
            f"FROM {self._db}.tool_calls WHERE {where} "
            f"GROUP BY ts_bucket ORDER BY ts_bucket"
        )
        return [TimeseriesPoint(ts=int(r[0]), value=int(r[1])) for r in rows]

    async def llm_timeseries(
        self,
        *,
        since_ts: int,
        until_ts: int,
        bucket: str,
    ) -> list[TimeseriesPoint]:
        """Time-bucketed count of llm_call events."""
        where = self._ts_where(since_ts, until_ts)
        fn = self._bucket_fn(bucket)
        rows = await self._query(
            f"SELECT toUnixTimestamp({fn}(ts)) * 1000 AS ts_bucket, count() AS cnt "
            f"FROM {self._db}.llm_calls WHERE {where} "
            f"GROUP BY ts_bucket ORDER BY ts_bucket"
        )
        return [TimeseriesPoint(ts=int(r[0]), value=int(r[1])) for r in rows]

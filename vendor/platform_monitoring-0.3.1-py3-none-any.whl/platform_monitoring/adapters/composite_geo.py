import ipaddress

from platform_monitoring.envelope import Geo
from platform_monitoring.ports.geo_resolver import GeoResolver

_PRIVATE_NETS = [
    ipaddress.ip_network(cidr)
    for cidr in (
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "127.0.0.0/8",
        "::1/128",
        "fc00::/7",
        "169.254.0.0/16",
    )
]


def _is_private(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return any(addr in net for net in _PRIVATE_NETS)
    except ValueError:
        return False


def _has_coords(geo: Geo) -> bool:
    """Return True if the Geo has meaningful non-zero lat/lon coordinates."""
    return (
        geo.lat is not None and geo.lon is not None
        and (geo.lat != 0.0 or geo.lon != 0.0)
    )


class CompositeGeo:
    """CF headers first, GeoLite2 enrichment/fallback. Private/LAN IPs → source='none'.

    Resolution logic:
    1. Private IP → return Geo(source='none') immediately.
    2. Ask CF resolver.
       a. CF has no country → fall through to GeoLite2 entirely.
       b. CF has country + coords (Enterprise) → return CF result as-is.
       c. CF has country but no coords (non-Enterprise, most common) →
          ask GeoLite2 for the same IP and, if GeoLite2 has coordinates,
          return an enriched Geo that merges CF's country with GeoLite2's
          lat/lon, source='cloudflare+geolite2'.
          If GeoLite2 has no coords either, return CF result unchanged.
    """

    def __init__(self, *, cf_resolver: GeoResolver, lite2_resolver: GeoResolver) -> None:
        self._cf = cf_resolver
        self._lite2 = lite2_resolver

    async def resolve(self, ip: str) -> Geo:
        if _is_private(ip):
            return Geo(source="none")

        cf_result = await self._cf.resolve(ip)

        if not cf_result.country:
            # CF has nothing useful; delegate entirely to GeoLite2.
            return await self._lite2.resolve(ip)

        if _has_coords(cf_result):
            # CF already has coordinates (Enterprise plan) — use as-is.
            return cf_result

        # CF has country but no coords.  Try to enrich with GeoLite2 lat/lon.
        lite2_result = await self._lite2.resolve(ip)
        if _has_coords(lite2_result):
            return Geo(
                country=cf_result.country,
                city=lite2_result.city or cf_result.city,
                lat=lite2_result.lat,
                lon=lite2_result.lon,
                source="cloudflare+geolite2",
            )

        # GeoLite2 had no coords either — keep CF result unchanged.
        return cf_result

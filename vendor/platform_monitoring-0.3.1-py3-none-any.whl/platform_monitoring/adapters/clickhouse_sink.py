import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import clickhouse_connect

from platform_monitoring.envelope import (
    REQUEST_COLUMNS,
    MonitoringEvent,
    event_to_request_row,
)
from platform_monitoring.models import Alert, Block
from platform_monitoring.query_models import (
    ActorSpec,
    ActorSummary,
    GeoBucket,
    GeoSpec,
    OverviewResult,
    OverviewSpec,
    Page,
    Point,
    RequestFilter,
    RequestRow,
    TimeseriesSpec,
    TopRow,
    TopSpec,
)

_SCHEMA_DIR = Path(__file__).resolve().parent.parent / "schema" / "clickhouse"


def _has_executable_sql(statement: str) -> bool:
    """True if a ';'-split fragment contains real SQL (not just blanks/`--` comments)."""
    return any(
        line.strip() and not line.strip().startswith("--") for line in statement.splitlines()
    )


class ClickHouseSink:
    """ClickHouse-backed EventSink. Connects to the server (default DB) and
    fully-qualifies all objects with the configured database name."""

    def __init__(self, url: str, *, database: str = "mon", raw_retention_days: int = 30) -> None:
        parts = urlsplit(url)
        self._client = clickhouse_connect.get_client(
            host=parts.hostname or "localhost",
            port=parts.port or 8123,
            username=parts.username or "default",
            password=parts.password or "",
            database="default",
        )
        self._db = database
        self._retention = raw_retention_days

    async def _command(self, sql: str) -> None:
        await asyncio.to_thread(self._client.command, sql)

    async def _query(self, sql: str) -> list[tuple[Any, ...]]:
        result = await asyncio.to_thread(self._client.query, sql)
        return list(result.result_rows)

    async def bootstrap_schema(self) -> None:
        for path in sorted(_SCHEMA_DIR.glob("*.sql")):
            text = path.read_text().format(db=self._db, raw_retention_days=self._retention)
            for statement in (s.strip() for s in text.split(";")):
                if _has_executable_sql(statement):
                    await self._command(statement)

    async def write_batch(self, events: list[MonitoringEvent]) -> None:
        if not events:
            return
        rows = [event_to_request_row(ev) for ev in events]
        await asyncio.to_thread(
            self._client.insert,
            f"{self._db}.requests",
            rows,
            column_names=REQUEST_COLUMNS,
        )

    @staticmethod
    def _ms_to_dt(ts_ms: int) -> datetime:
        """Convert epoch-milliseconds to a timezone-aware datetime (UTC)."""
        return datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)

    async def write_alert_audit(self, alert: Alert) -> None:
        """Append one row to {db}.alerts (best-effort — never raises)."""
        rows = [
            [
                alert.id,
                self._ms_to_dt(alert.ts),  # DateTime64(3) requires datetime object
                alert.rule_id,
                alert.severity,
                alert.subject_type,
                alert.subject,
                alert.summary,
                json.dumps(alert.details),
                alert.auto_action,
            ]
        ]
        await asyncio.to_thread(
            self._client.insert,
            f"{self._db}.alerts",
            rows,
            column_names=[
                "alert_id",
                "ts",
                "rule_id",
                "severity",
                "subject_type",
                "subject",
                "summary",
                "details",
                "auto_action",
            ],
        )

    async def write_block_audit(self, block: Block, action: str) -> None:
        """Append one row to {db}.block_audit (best-effort — never raises)."""
        now_dt = datetime.fromtimestamp(time.time(), tz=timezone.utc)
        rows = [
            [
                now_dt,  # DateTime64(3) requires datetime object
                block.subject_type,
                block.subject,
                block.mode,
                block.reason,
                block.source,
                block.created_by,
                block.until,  # Nullable(Int64) — None is fine
                action,
            ]
        ]
        await asyncio.to_thread(
            self._client.insert,
            f"{self._db}.block_audit",
            rows,
            column_names=[
                "ts",
                "subject_type",
                "subject",
                "mode",
                "reason",
                "source",
                "created_by",
                "until",
                "action",
            ],
        )

    async def aclose(self) -> None:
        await asyncio.to_thread(self._client.close)

    # ── Read (Plan 2): query methods ─────────────────────────────────────────

    @staticmethod
    def _esc(value: str) -> str:
        """Escape a string value for safe interpolation into single-quoted SQL literals."""
        return value.replace("\\", "\\\\").replace("'", "\\'")

    async def query_overview(self, spec: OverviewSpec) -> OverviewResult:
        row = (
            await self._query(
                f"SELECT count(), countIf(status>=400), quantile(0.95)(latency_ms), "
                f"uniq(ip), countIf(was_blocked=1) "
                f"FROM {self._db}.requests "
                f"WHERE ts >= fromUnixTimestamp64Milli({int(spec.from_ts)}) "
                f"  AND ts <  fromUnixTimestamp64Milli({int(spec.to_ts)})"
            )
        )[0]
        total = int(row[0])
        errors = int(row[1])
        error_rate = errors / total if total else 0.0
        return OverviewResult(
            requests_total=total,
            requests_1m=0,  # filled by QueryService from Redis
            error_rate=error_rate,
            p95_latency_ms=float(row[2]) if row[2] is not None else None,
            unique_ips=int(row[3]),
            unique_ips_hll=0,  # filled by QueryService from Redis
            blocked_total=int(row[4]),
            open_alerts=0,  # Phase-2
        )

    async def query_timeseries(self, spec: TimeseriesSpec) -> list[Point]:
        gran_fn = {"minute": "toStartOfMinute", "hour": "toStartOfHour", "day": "toStartOfDay"}.get(
            spec.granularity, "toStartOfMinute"
        )
        where_clauses = [
            f"ts >= fromUnixTimestamp64Milli({int(spec.from_ts)})",
            f"ts <  fromUnixTimestamp64Milli({int(spec.to_ts)})",
        ]
        if spec.actor_type:
            where_clauses.append(f"actor_type = '{self._esc(spec.actor_type)}'")
        if spec.country:
            where_clauses.append(f"ip_country = '{self._esc(spec.country)}'")
        if spec.route:
            where_clauses.append(f"route = '{self._esc(spec.route)}'")
        where = " AND ".join(where_clauses)
        rows = await self._query(
            f"SELECT toUnixTimestamp({gran_fn}(ts)) * 1000 AS bucket, "
            f"count() AS requests, "
            f"countIf(status>=400 AND status<500) AS e4, "
            f"countIf(status>=500) AS e5, "
            f"quantile(0.95)(latency_ms) AS p95 "
            f"FROM {self._db}.requests WHERE {where} "
            f"GROUP BY bucket ORDER BY bucket"
        )
        return [
            Point(
                ts=int(r[0]),
                requests=int(r[1]),
                errors_4xx=int(r[2]),
                errors_5xx=int(r[3]),
                p95_ms=float(r[4]) if r[4] is not None else None,
            )
            for r in rows
        ]

    async def query_top(self, spec: TopSpec) -> list[TopRow]:
        dim_col = {
            "ip": "ip",
            "route": "route",
            "country": "ip_country",
            "actor": (
                "multiIf(actor_type='ui_user',user_id,"
                "actor_type='mcp',caller_identity,"
                "actor_type='api_key',api_key_id,'anonymous')"
            ),
        }.get(spec.dimension, "ip")
        where_clauses = [
            f"ts >= fromUnixTimestamp64Milli({int(spec.from_ts)})",
            f"ts <  fromUnixTimestamp64Milli({int(spec.to_ts)})",
        ]
        if spec.actor_type:
            where_clauses.append(f"actor_type = '{self._esc(spec.actor_type)}'")
        where = " AND ".join(where_clauses)
        rows = await self._query(
            f"SELECT {dim_col} AS label, count() AS requests, "
            f"countIf(status>=400 AND status<500) AS e4, "
            f"countIf(status>=500) AS e5, "
            f"quantile(0.95)(latency_ms) AS p95 "
            f"FROM {self._db}.requests WHERE {where} "
            f"GROUP BY label ORDER BY requests DESC LIMIT {int(spec.limit)}"
        )
        return [
            TopRow(
                label=str(r[0]),
                requests=int(r[1]),
                errors_4xx=int(r[2]),
                errors_5xx=int(r[3]),
                p95_ms=float(r[4]) if r[4] is not None else None,
            )
            for r in rows
        ]

    async def query_geo(self, spec: GeoSpec) -> list[GeoBucket]:
        rows = await self._query(
            f"SELECT ip_country, count() AS requests, "
            f"countIf(status>=400 AND status<500) AS e4, "
            f"countIf(status>=500) AS e5, uniq(ip) AS uips "
            f"FROM {self._db}.requests "
            f"WHERE ts >= fromUnixTimestamp64Milli({int(spec.from_ts)}) "
            f"  AND ts <  fromUnixTimestamp64Milli({int(spec.to_ts)}) "
            f"  AND ip_country != '' "
            f"GROUP BY ip_country ORDER BY requests DESC LIMIT {int(spec.limit)}"
        )
        return [
            GeoBucket(
                country=str(r[0]),
                requests=int(r[1]),
                errors_4xx=int(r[2]),
                errors_5xx=int(r[3]),
                unique_ips=int(r[4]),
            )
            for r in rows
        ]

    async def query_requests(self, filt: RequestFilter) -> Page[RequestRow]:
        where_clauses = [
            f"ts >= fromUnixTimestamp64Milli({int(filt.from_ts)})",
            f"ts <  fromUnixTimestamp64Milli({int(filt.to_ts)})",
        ]
        if filt.actor_type:
            where_clauses.append(f"actor_type = '{self._esc(filt.actor_type)}'")
        if filt.country:
            where_clauses.append(f"ip_country = '{self._esc(filt.country)}'")
        if filt.route:
            where_clauses.append(f"route = '{self._esc(filt.route)}'")
        if filt.ip:
            where_clauses.append(f"ip = '{self._esc(filt.ip)}'")
        if filt.status is not None:
            where_clauses.append(f"status = {int(filt.status)}")
        where = " AND ".join(where_clauses)
        count_row = (await self._query(f"SELECT count() FROM {self._db}.requests WHERE {where}"))[0]
        total = int(count_row[0])
        rows = await self._query(
            f"SELECT request_id, toUnixTimestamp64Milli(ts), method, route, path, "
            f"status, latency_ms, resp_bytes, actor_type, "
            f"multiIf(actor_type='ui_user',user_id,actor_type='mcp',caller_identity,"
            f"actor_type='api_key',api_key_id,'anonymous') AS actor_id, "
            f"ip, ip_country, ip_city, geo_source, user_agent, "
            f"was_blocked, was_rate_limited, block_reason "
            f"FROM {self._db}.requests WHERE {where} "
            f"ORDER BY ts DESC LIMIT {int(filt.limit)} OFFSET {int(filt.offset)}"
        )
        items = [
            RequestRow(
                request_id=str(r[0]),
                ts=int(r[1]),
                method=str(r[2]),
                route=str(r[3]),
                path=str(r[4]),
                status=int(r[5]),
                latency_ms=int(r[6]),
                resp_bytes=int(r[7]),
                actor_type=str(r[8]),
                actor_id=str(r[9]),
                ip=str(r[10]),
                country=str(r[11]) or None,
                city=str(r[12]) or None,
                geo_source=str(r[13]),
                user_agent=str(r[14]),
                was_blocked=bool(r[15]),
                was_rate_limited=bool(r[16]),
                block_reason=str(r[17]),
            )
            for r in rows
        ]
        return Page(items=items, total=total, limit=filt.limit, offset=filt.offset)

    async def query_actor(self, spec: ActorSpec) -> ActorSummary:
        actor_col = {
            "ui_user": "user_id",
            "mcp": "caller_identity",
            "api_key": "api_key_id",
        }.get(spec.actor_type, "user_id")
        where = (
            f"ts >= fromUnixTimestamp64Milli({int(spec.from_ts)}) "
            f"AND ts < fromUnixTimestamp64Milli({int(spec.to_ts)}) "
            f"AND actor_type = '{self._esc(spec.actor_type)}' "
            f"AND {actor_col} = '{self._esc(spec.actor_id)}'"
        )
        row = (
            await self._query(
                f"SELECT count(), countIf(status>=400 AND status<500), "
                f"countIf(status>=500), quantile(0.95)(latency_ms), "
                f"toUnixTimestamp64Milli(min(ts)), toUnixTimestamp64Milli(max(ts)) "
                f"FROM {self._db}.requests WHERE {where}"
            )
        )[0]
        route_rows = await self._query(
            f"SELECT route, count() AS requests, "
            f"countIf(status>=400 AND status<500), countIf(status>=500), "
            f"quantile(0.95)(latency_ms) "
            f"FROM {self._db}.requests WHERE {where} "
            f"GROUP BY route ORDER BY requests DESC LIMIT 10"
        )
        top_routes = [
            TopRow(
                label=str(r[0]),
                requests=int(r[1]),
                errors_4xx=int(r[2]),
                errors_5xx=int(r[3]),
                p95_ms=float(r[4]) if r[4] is not None else None,
            )
            for r in route_rows
        ]
        return ActorSummary(
            actor_type=spec.actor_type,
            actor_id=spec.actor_id,
            requests_total=int(row[0]),
            errors_4xx=int(row[1]),
            errors_5xx=int(row[2]),
            p95_ms=float(row[3]) if row[3] is not None else None,
            first_seen_ts=int(row[4]) if row[4] is not None else None,
            last_seen_ts=int(row[5]) if row[5] is not None else None,
            top_routes=top_routes,
        )

# src/platform_monitoring/adapters/redis_hot_store.py
import ipaddress
import json
import secrets
import time
from typing import Any, cast

import redis.asyncio as redis
from redis.exceptions import ResponseError

from platform_monitoring.envelope import MonitoringEvent
from platform_monitoring.models import Alert, Block, Rule

_BUCKET_SIZE = 10  # seconds; 10s granularity for sliding window


def _wc_key(dim: str, ident: str, bucket_ts: int) -> str:
    return f"mon:wc:{dim}:{ident}:{bucket_ts}"


def _block_key(subject_type: str, subject: str) -> str:
    return f"mon:block:{subject_type}:{subject}"


class RedisHotStore:
    """Redis-backed HotStore: stream buffer + real-time counters + Phase-2 control plane."""

    def __init__(
        self,
        url: str,
        *,
        stream: str = "mon:events",
        group: str = "mon:ingest",
        consumer: str = "worker-1",
        stream_maxlen: int = 1_000_000,
    ) -> None:
        self._r = redis.from_url(url, decode_responses=True)
        self._stream = stream
        self._group = group
        self._consumer = consumer
        self._maxlen = stream_maxlen

    # ── Phase-1: stream I/O ───────────────────────────────────────────────────

    async def emit(self, event: MonitoringEvent) -> None:
        await self._r.xadd(
            self._stream,
            {"data": event.model_dump_json()},
            maxlen=self._maxlen,
            approximate=True,
        )

    async def ensure_group(self) -> None:
        try:
            await self._r.xgroup_create(self._stream, self._group, id="0", mkstream=True)
        except ResponseError as e:
            if "BUSYGROUP" not in str(e):
                raise

    async def read_batch(self, count: int, block_ms: int) -> list[tuple[str, MonitoringEvent]]:
        resp = await self._r.xreadgroup(
            self._group, self._consumer, {self._stream: ">"}, count=count, block=block_ms
        )
        if not resp:
            return []
        out: list[tuple[str, MonitoringEvent]] = []
        for _sname, entries in resp:
            for entry_id, fields in entries:
                out.append((entry_id, MonitoringEvent.model_validate_json(fields["data"])))
        return out

    async def read_pending(self, count: int) -> list[tuple[str, MonitoringEvent]]:
        resp = await self._r.xreadgroup(
            self._group, self._consumer, {self._stream: "0"}, count=count
        )
        if not resp:
            return []
        out: list[tuple[str, MonitoringEvent]] = []
        for _sname, entries in resp:
            for entry_id, fields in entries:
                out.append((entry_id, MonitoringEvent.model_validate_json(fields["data"])))
        return out

    async def ack(self, ids: list[str]) -> None:
        if ids:
            await self._r.xack(self._stream, self._group, *ids)

    # ── Phase-1: counters (extended for real sliding window) ──────────────────

    async def bump_counters(self, event: MonitoringEvent) -> None:
        ip = event.source_ip
        now_s = event.ts // 1000
        minute = now_s // 60
        bucket_ts = (now_s // _BUCKET_SIZE) * _BUCKET_SIZE
        pipe = self._r.pipeline()

        # Global all-events counter (original Phase-1 key — kept for backward compat)
        all_key = f"mon:cnt:all:all:{minute}"
        pipe.incr(all_key)
        pipe.expire(all_key, 120)

        # Phase-2: sliding-window bucket for global all:all dimension (always written)
        all_wc = _wc_key("all", "all", bucket_ts)
        pipe.incr(all_wc)
        pipe.expire(all_wc, 3630)

        if ip:
            # Phase-1 per-minute top/HLL keys
            top_key = f"mon:top:ip:{minute}"
            pipe.zincrby(top_key, 1, ip)
            pipe.expire(top_key, 3600)
            hll_key = f"mon:hll:uniq:{minute}"
            pipe.pfadd(hll_key, ip)
            pipe.expire(hll_key, 3600)
            # Phase-1 per-minute window key (kept; Phase-2 adds finer buckets below)
            win_key = f"mon:cnt:ip:{ip}:{minute}"
            pipe.incr(win_key)
            pipe.expire(win_key, 120)

            # Phase-2: sliding-window 10s-bucket keys  (key: mon:wc:ip:{ip}:{bucket_ts})
            ip_wc = _wc_key("ip", ip, bucket_ts)
            pipe.incr(ip_wc)
            pipe.expire(ip_wc, 3630)  # max_window(3600) + 30s slack

        # Phase-2: sliding-window bucket for route dimension
        route = str(event.attrs.get("route", "")) if event.attrs else ""
        if route:
            route_wc = _wc_key("route", route, bucket_ts)
            pipe.incr(route_wc)
            pipe.expire(route_wc, 3630)

        # Phase-2: sliding-window bucket for user dimension
        user_id = event.actor.user_id if event.actor.user_id else ""
        if user_id:
            user_wc = _wc_key("user", user_id, bucket_ts)
            pipe.incr(user_wc)
            pipe.expire(user_wc, 3630)

        # Phase-2: sliding-window bucket for caller dimension
        caller = event.actor.caller_identity if event.actor.caller_identity else ""
        if caller:
            caller_wc = _wc_key("caller", caller, bucket_ts)
            pipe.incr(caller_wc)
            pipe.expire(caller_wc, 3630)

        # Phase-2: metric=errors — count if status >= 400
        status = int(event.attrs.get("status", 0)) if event.attrs else 0
        if status >= 400 and ip:
            err_wc = _wc_key("errors", ip, bucket_ts)
            pipe.incr(err_wc)
            pipe.expire(err_wc, 3630)

        await pipe.execute()

    async def window_count(self, dim: str, ident: str, window_s: int) -> int:
        """True sliding window: sum 10s bucket keys covering [now-window_s, now]."""
        now_s = int(time.time())
        start_bucket = ((now_s - window_s) // _BUCKET_SIZE) * _BUCKET_SIZE
        end_bucket = (now_s // _BUCKET_SIZE) * _BUCKET_SIZE
        keys = [
            _wc_key(dim, ident, b)
            for b in range(start_bucket, end_bucket + _BUCKET_SIZE, _BUCKET_SIZE)
        ]
        if not keys:
            return 0
        vals = await self._r.mget(*keys)
        return sum(int(v) for v in vals if v)

    # ── Phase-2: internal helpers ─────────────────────────────────────────────

    def _actor_subjects(self, actor: object) -> list[str]:
        """Return all subject identifiers for an actor (user_id, caller_identity)."""
        subjects: list[str] = []
        actor_any: Any = actor
        if actor_any.user_id:
            subjects.append(actor_any.user_id)
        if actor_any.caller_identity:
            subjects.append(actor_any.caller_identity)
        return subjects

    async def _smembers(self, key: str) -> set[str]:
        """Typed wrapper: awaits smembers and returns set[str]."""
        return cast(set[str], await cast(Any, self._r.smembers(key)))

    async def _hgetall(self, key: str) -> dict[str, str]:
        """Typed wrapper: awaits hgetall and returns dict[str, str]."""
        return cast(dict[str, str], await cast(Any, self._r.hgetall(key)))

    # ── Phase-2: enforcement — blocks ─────────────────────────────────────────

    async def is_allowlisted(self, ip: str | None, actor: object) -> bool:
        """Return True if ip matches any allowlist CIDR or actor user_id is prefixed with 'u:'."""
        entries = await self._smembers("mon:allowlist")
        if not entries:
            return False
        # Check actor-level allowlist entries (stored as "u:{user_id}")
        for subj in self._actor_subjects(actor):
            if f"u:{subj}" in entries:
                return True
        # Check IP-level entries (CIDR or exact)
        if ip:
            try:
                addr = ipaddress.ip_address(ip)
                for entry in entries:
                    if entry.startswith("u:"):
                        continue
                    try:
                        if addr in ipaddress.ip_network(entry, strict=False):
                            return True
                    except ValueError:
                        if ip == entry:
                            return True
            except ValueError:
                pass
        return False

    async def get_allowlist(self) -> list[str]:
        return list(await self._smembers("mon:allowlist"))

    async def set_allowlist(self, entries: list[str]) -> None:
        pipe = self._r.pipeline()
        pipe.delete("mon:allowlist")
        if entries:
            pipe.sadd("mon:allowlist", *entries)
        await pipe.execute()

    async def enforcement_enabled(self) -> bool:
        val: str | None = await self._r.get("mon:enforce:enabled")
        return val != "0"  # default None -> True; "1" -> True; "0" -> False

    async def set_enforcement_enabled(self, on: bool) -> None:
        await self._r.set("mon:enforce:enabled", "1" if on else "0")

    async def add_block(self, block: Block) -> None:
        key = _block_key(block.subject_type, block.subject)
        data: dict[str, str] = {
            "subject_type": block.subject_type,
            "subject": block.subject,
            "reason": block.reason,
            "mode": block.mode,
            "until": str(block.until) if block.until is not None else "",
            "scope": block.scope,
            "sync_targets": json.dumps(block.sync_targets),
            "source": block.source,
            "created_by": block.created_by,
        }
        pipe = self._r.pipeline()
        pipe.hset(key, mapping=data)
        if block.until is not None:
            ttl_s = max(1, (block.until - int(time.time() * 1000)) // 1000)
            pipe.expire(key, ttl_s)
        await pipe.execute()

    def _hash_to_block(self, data: dict[str, str]) -> Block:
        until_raw = data.get("until", "")
        return Block(
            subject_type=data["subject_type"],  # type: ignore[arg-type]
            subject=data["subject"],
            reason=data.get("reason", ""),
            mode=data.get("mode", "block"),  # type: ignore[arg-type]
            until=int(until_raw) if until_raw else None,
            scope=data.get("scope", "app"),
            sync_targets=json.loads(data.get("sync_targets", "[]")),
            source=data.get("source", "manual"),  # type: ignore[arg-type]
            created_by=data.get("created_by", ""),
        )

    async def remove_block(self, subject_type: str, subject: str) -> None:
        await self._r.delete(_block_key(subject_type, subject))

    async def list_blocks(self) -> list[Block]:
        blocks: list[Block] = []
        async for key in self._r.scan_iter(match="mon:block:*"):
            data = await self._hgetall(key)
            if data:
                blocks.append(self._hash_to_block(data))
        return blocks

    async def is_blocked(self, actor: object, ip: str | None) -> Block | None:
        """Return the first active Block for this actor/IP, or None if allowlisted/not blocked.

        The global kill-switch is authoritative: when enforcement is disabled, no
        subject is ever reported blocked, so the middleware serves normally — an
        instant, global off-switch even for already-written blocks.
        """
        if not await self.enforcement_enabled():
            return None
        if await self.is_allowlisted(ip, actor):
            return None
        # Check IP block
        if ip:
            data = await self._hgetall(_block_key("ip", ip))
            if data:
                return self._hash_to_block(data)
        # Check user / caller blocks
        for subj in self._actor_subjects(actor):
            data = await self._hgetall(_block_key("user", subj))
            if data:
                return self._hash_to_block(data)
            data = await self._hgetall(_block_key("caller", subj))
            if data:
                return self._hash_to_block(data)
        return None

    # ── Phase-2: throttle ─────────────────────────────────────────────────────

    async def get_throttle(self, subject: str) -> int | None:
        val: str | None = await self._r.get(f"mon:throttle:{subject}")
        return int(val) if val is not None else None

    async def set_throttle(self, subject: str, limit_per_min: int | None) -> None:
        key = f"mon:throttle:{subject}"
        if limit_per_min is None:
            await self._r.delete(key)
        else:
            await self._r.set(key, str(limit_per_min))

    async def list_throttles(self) -> dict[str, int]:
        """Return all currently set throttles as {subject: limit_per_min}."""
        result: dict[str, int] = {}
        prefix = "mon:throttle:"
        async for key in self._r.scan_iter(match=f"{prefix}*"):
            val: str | None = await self._r.get(key)
            if val is not None:
                subject = key[len(prefix) :]
                result[subject] = int(val)
        return result

    # ── Phase-2: rules ────────────────────────────────────────────────────────

    async def get_rules(self) -> list[Rule]:
        raw: str | None = await self._r.get("mon:rules")
        if not raw:
            return []
        return [Rule.model_validate(r) for r in json.loads(raw)]

    async def put_rules(self, rules: list[Rule]) -> None:
        await self._r.set("mon:rules", json.dumps([r.model_dump() for r in rules]))

    # ── Phase-2: alerts ───────────────────────────────────────────────────────

    async def raise_alert(self, alert: Alert) -> None:
        key = f"mon:alert:{alert.id}"
        data: dict[str, str] = {
            "id": alert.id,
            "ts": str(alert.ts),
            "rule_id": alert.rule_id,
            "severity": alert.severity,
            "subject_type": alert.subject_type,
            "subject": alert.subject,
            "summary": alert.summary,
            "details": json.dumps(alert.details),
            "status": alert.status,
            "auto_action": alert.auto_action,
        }
        pipe = self._r.pipeline(transaction=True)
        pipe.hset(key, mapping=data)
        pipe.xadd("mon:alerts:stream", {"data": alert.model_dump_json()})
        await pipe.execute()

    def _hash_to_alert(self, data: dict[str, str]) -> Alert:
        return Alert(
            id=data["id"],
            ts=int(data["ts"]),
            rule_id=data["rule_id"],
            severity=data["severity"],
            subject_type=data["subject_type"],
            subject=data["subject"],
            summary=data["summary"],
            details=json.loads(data.get("details", "{}")),
            status=data.get("status", "open"),  # type: ignore[arg-type]
            auto_action=data.get("auto_action", ""),
        )

    async def get_alert(self, alert_id: str) -> Alert | None:
        data = await self._hgetall(f"mon:alert:{alert_id}")
        return self._hash_to_alert(data) if data else None

    async def set_alert_status(self, alert_id: str, status: str) -> None:
        await cast(Any, self._r.hset(f"mon:alert:{alert_id}", "status", status))

    async def list_alerts(self, status: str | None, limit: int) -> list[Alert]:
        alerts: list[Alert] = []
        async for key in self._r.scan_iter(match="mon:alert:*"):
            data = await self._hgetall(key)
            if not data:
                continue
            a = self._hash_to_alert(data)
            if status is None or a.status == status:
                alerts.append(a)
        alerts.sort(key=lambda a: a.ts, reverse=True)
        return alerts[:limit]

    async def read_alerts_stream(
        self, last_id: str, block_ms: int, count: int
    ) -> list[tuple[str, Alert]]:
        resp = await self._r.xread({"mon:alerts:stream": last_id}, count=count, block=block_ms)
        if not resp:
            return []
        out: list[tuple[str, Alert]] = []
        for _sname, entries in resp:
            for entry_id, fields in entries:
                out.append((entry_id, Alert.model_validate_json(fields["data"])))
        return out

    async def read_events_stream(
        self, last_id: str, block_ms: int, count: int
    ) -> list[tuple[str, MonitoringEvent]]:
        resp = await self._r.xread({self._stream: last_id}, count=count, block=block_ms)
        if not resp:
            return []
        out: list[tuple[str, MonitoringEvent]] = []
        for _sname, entries in resp:
            for entry_id, fields in entries:
                out.append((entry_id, MonitoringEvent.model_validate_json(fields["data"])))
        return out

    # ── Phase-2: cooldown ─────────────────────────────────────────────────────

    async def cooldown_ok(self, rule_id: str, subject: str, cooldown_s: int) -> bool:
        """Returns True and sets the cooldown key (NX EX) if cooldown has not fired recently."""
        key = f"mon:cd:{rule_id}:{subject}"
        result = await self._r.set(key, "1", nx=True, ex=cooldown_s)
        return result is not None  # True = SET succeeded (was not already set)

    # ── Phase-2: WS tickets ───────────────────────────────────────────────────

    async def issue_ws_ticket(self, ttl_s: int = 30) -> str:
        token = secrets.token_hex(24)
        await self._r.set(f"mon:wsticket:{token}", "1", ex=ttl_s)
        return token

    async def consume_ws_ticket(self, ticket: str) -> bool:
        val: str | None = await self._r.getdel(f"mon:wsticket:{ticket}")
        return val is not None

    # ── Phase-2: stream cursor helpers ────────────────────────────────────────

    async def get_stream_latest_id(self, stream: str) -> str:
        """Return the latest entry ID in a stream ("0" if empty).

        Maps stream name tokens to actual Redis stream keys:
          "events" → self._stream  (the main events/requests stream)
          "alerts" → "mon:alerts:stream"
          anything else treated as a literal key name.
        """
        stream_key = (
            self._stream
            if stream == "events"
            else "mon:alerts:stream"
            if stream == "alerts"
            else stream
        )
        # XREVRANGE stream + - COUNT 1  → [(id, fields)] or []
        entries: list[tuple[str, dict[str, str]]] = await self._r.xrevrange(
            stream_key, "+", "-", count=1
        )
        if entries:
            return entries[0][0]
        return "0"

    async def aclose(self) -> None:
        await self._r.aclose()

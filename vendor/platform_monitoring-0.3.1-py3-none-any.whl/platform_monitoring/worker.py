import asyncio
import json
import logging
import signal
from typing import Any

from redis.asyncio import Redis as AsyncRedis

from platform_monitoring.envelope import MonitoringEvent
from platform_monitoring.ports.event_sink import EventSink
from platform_monitoring.ports.hot_store import HotStore, get_hot_store
from platform_monitoring.ports.usage_sink import UsageSink
from platform_monitoring.usage.events import (
    LlmCallEvent,
    StepRunEvent,
    ToolCallEvent,
    UsageEventBase,
)

log = logging.getLogger("platform_monitoring.worker")


class IngestionWorker:
    """Drains the Redis stream into the EventSink, bumps hot counters, and runs the RuleEngine."""

    def __init__(
        self,
        *,
        hot_store: HotStore,
        sink: EventSink,
        batch_size: int = 500,
        block_ms: int = 1000,
        rule_engine: Any | None = None,  # platform_monitoring.rule_engine.RuleEngine | None
    ) -> None:
        self._hot = hot_store
        self._sink = sink
        self._batch = batch_size
        self._block_ms = block_ms
        self._engine = rule_engine
        self._stop = asyncio.Event()

    async def _handle(self, batch: list[tuple[str, MonitoringEvent]]) -> int:
        if not batch:
            return 0
        events = [ev for _, ev in batch]
        # write_batch first; only ack if it succeeds (at-least-once delivery).
        await self._sink.write_batch(events)
        for ev in events:
            try:
                await self._hot.bump_counters(ev)
            except Exception:  # counters are best-effort; never block ingestion
                log.warning("bump_counters failed", exc_info=True)
        # Rule engine evaluation — best-effort: errors must never stop ingestion or acking
        if self._engine is not None:
            try:
                rules = await self._hot.get_rules()
                await self._engine.evaluate(events, rules=rules)
            except Exception:
                log.warning("rule_engine.evaluate failed — continuing ingestion", exc_info=True)
        await self._hot.ack([sid for sid, _ in batch])
        return len(batch)

    async def process_once(self) -> int:
        """Read one batch of new messages ('>') and process it."""
        batch = await self._hot.read_batch(count=self._batch, block_ms=self._block_ms)
        return await self._handle(batch)

    async def process_pending(self) -> int:
        """Reclaim and process this consumer's pending (unacked) messages."""
        batch = await self._hot.read_pending(count=self._batch)
        return await self._handle(batch)

    async def run_forever(self) -> None:
        await self._hot.ensure_group()
        # Reclaim ALL messages delivered-but-unacked by a previous crash of this
        # consumer before processing new ones (at-least-once recovery). Drain the
        # pending list batch-by-batch until empty so a backlog larger than one
        # batch is fully recovered in a single startup.
        try:
            while not self._stop.is_set():
                reclaimed = await self.process_pending()
                if not reclaimed:
                    break
                log.info("reclaimed %d pending message(s) at startup", reclaimed)
        except Exception:
            log.exception("startup pending reclaim failed; continuing")
        log.info("monitoring worker started")
        while not self._stop.is_set():
            try:
                await self.process_once()
            except Exception:  # one bad batch must not kill the loop
                log.exception("ingestion batch failed; will retry")
                await asyncio.sleep(1.0)

    def stop(self) -> None:
        self._stop.set()


# ── Usage worker — second consumer group on mon:usage ────────────────────────


def _deserialize_usage_event(data: bytes | str) -> UsageEventBase | None:
    """Deserialize a JSON payload from the mon:usage stream into a typed event."""
    try:
        obj = json.loads(data)
        kind = obj.get("kind")
        if kind == "tool_call":
            return ToolCallEvent.model_validate(obj)
        elif kind == "step_run":
            return StepRunEvent.model_validate(obj)
        elif kind == "llm_call":
            return LlmCallEvent.model_validate(obj)
        else:
            log.warning("UsageIngestionWorker: unknown kind=%s — dropping", kind)
            return None
    except Exception:
        log.warning("UsageIngestionWorker: failed to deserialize event — dropping", exc_info=True)
        return None


class UsageIngestionWorker:
    """Drains the mon:usage Redis stream into the UsageSink.

    Second consumer group in the same worker process; shares the ClickHouseUsageSink.
    Same at-least-once, write-before-ack discipline as IngestionWorker.
    """

    def __init__(
        self,
        *,
        redis: AsyncRedis,
        sink: UsageSink,
        stream: str = "mon:usage",
        group: str = "usage",
        consumer: str = "worker",
        batch_size: int = 500,
        block_ms: int = 1000,
    ) -> None:
        self._r = redis
        self._sink = sink
        self._stream = stream
        self._group = group
        self._consumer = consumer
        self._batch = batch_size
        self._block_ms = block_ms
        self._stop = asyncio.Event()

    async def ensure_group(self) -> None:
        try:
            await self._r.xgroup_create(self._stream, self._group, id="0", mkstream=True)
        except Exception as exc:
            if "BUSYGROUP" not in str(exc):
                raise

    async def _read_batch(self, last_id: str) -> list[tuple[str, bytes | str]]:
        results = await self._r.xreadgroup(
            self._group,
            self._consumer,
            {self._stream: last_id},
            count=self._batch,
            block=self._block_ms,
        )
        if not results:
            return []
        entries = results[0][1]
        return [
            (
                entry_id.decode() if isinstance(entry_id, bytes) else entry_id,
                fields.get(b"data", fields.get("data", b"{}")),
            )
            for entry_id, fields in entries
        ]

    async def _handle(self, raw: list[tuple[str, bytes | str]]) -> int:
        if not raw:
            return 0
        events: list[UsageEventBase] = []
        ids: list[str] = []
        for entry_id, data in raw:
            ev = _deserialize_usage_event(data)
            if ev is not None:
                events.append(ev)
            ids.append(entry_id)
        # write-before-ack: if sink raises, we don't ack → at-least-once
        await self._sink.write_usage_batch(events)
        await self._r.xack(self._stream, self._group, *ids)
        return len(raw)

    async def process_once(self) -> int:
        """Read one batch of new messages ('>') and process it."""
        raw = await self._read_batch(">")
        return await self._handle(raw)

    async def process_pending(self) -> int:
        """Reclaim and process this consumer's pending (unacked) messages."""
        raw = await self._read_batch("0")
        return await self._handle(raw)

    async def run_forever(self) -> None:
        # Wrap ensure_group in its own retry loop so a transient Redis outage at
        # startup does NOT crash the worker (which under asyncio.gather would
        # also cancel the sibling IngestionWorker).
        while not self._stop.is_set():
            try:
                await self.ensure_group()
                break
            except Exception:
                log.exception("usage worker: ensure_group failed; retrying in 5s")
                await asyncio.sleep(5.0)
        try:
            while not self._stop.is_set():
                reclaimed = await self.process_pending()
                if not reclaimed:
                    break
                log.info("usage worker: reclaimed %d pending", reclaimed)
        except Exception:
            log.exception("usage worker startup reclaim failed; continuing")
        log.info("usage ingestion worker started on stream=%s group=%s", self._stream, self._group)
        while not self._stop.is_set():
            try:
                await self.process_once()
            except Exception:
                log.exception("usage batch failed; will retry")
                await asyncio.sleep(1.0)

    def stop(self) -> None:
        self._stop.set()


async def _amain() -> None:
    import redis.asyncio as aioredis

    from platform_monitoring.adapters.clickhouse_usage_sink import ClickHouseUsageSink
    from platform_monitoring.adapters.redis_hot_store import RedisHotStore
    from platform_monitoring.alert_delivery import LogOnlyDelivery, WebhookDelivery
    from platform_monitoring.ports.event_sink import register_event_sink
    from platform_monitoring.ports.hot_store import register_hot_store
    from platform_monitoring.rule_engine import RuleEngine
    from platform_monitoring.settings import MonitoringSettings

    logging.basicConfig(level=logging.INFO)
    s = MonitoringSettings()  # type: ignore[call-arg]
    register_hot_store(RedisHotStore(s.monitoring_redis_url, stream_maxlen=s.stream_maxlen))
    # ClickHouseUsageSink is a drop-in superset of ClickHouseSink; satisfies both
    # EventSink (write_batch) and UsageSink (write_usage_batch) protocols.
    sink = ClickHouseUsageSink(
        s.clickhouse_url,
        database=s.clickhouse_database,
        raw_retention_days=s.raw_retention_days,
        usage_retention_days=s.usage_retention_days,
    )
    await sink.bootstrap_schema()
    await sink.bootstrap_usage_schema()
    register_event_sink(sink)

    hot = get_hot_store()
    delivery = (
        WebhookDelivery(url=s.alert_webhook_url, secret=s.alert_webhook_secret)
        if s.alert_webhook_url
        else LogOnlyDelivery()
    )
    engine = RuleEngine(hot=hot, sink=sink, delivery=delivery)
    req_worker = IngestionWorker(hot_store=hot, sink=sink, rule_engine=engine)

    redis_client = aioredis.from_url(s.monitoring_redis_url)
    usage_worker = UsageIngestionWorker(
        redis=redis_client,
        sink=sink,
        stream="mon:usage",
        group="usage",
        consumer=s.usage_consumer_name,
    )

    loop = asyncio.get_running_loop()

    def _stop() -> None:
        req_worker.stop()
        usage_worker.stop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, _stop)
    try:
        # return_exceptions=True so one worker's terminal failure does NOT
        # cancel the sibling; we log and let the surviving worker keep
        # draining while the SIGTERM handler stops both cleanly.
        results = await asyncio.gather(
            req_worker.run_forever(),
            usage_worker.run_forever(),
            return_exceptions=True,
        )
        for name, result in zip(("req_worker", "usage_worker"), results, strict=True):
            if isinstance(result, BaseException):
                log.error("%s terminated with exception: %r", name, result)
    finally:
        await hot.aclose()
        await sink.aclose()
        await redis_client.aclose()


def main() -> None:
    asyncio.run(_amain())


if __name__ == "__main__":
    main()

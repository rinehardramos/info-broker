# src/platform_monitoring/rule_engine.py
"""RuleEngine — evaluates threshold rules against sliding-window counts (spec §5)."""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from platform_monitoring.alert_delivery import AlertDelivery
from platform_monitoring.envelope import MonitoringEvent
from platform_monitoring.models import Alert, Block, Rule
from platform_monitoring.ports.hot_store import HotStore

log = logging.getLogger("platform_monitoring.rule_engine")


# How to extract the subject identifier from an event for a given subject_dim
def _subjects_for_dim(dim: str, event: MonitoringEvent) -> list[str]:
    if dim == "ip":
        return [event.source_ip] if event.source_ip else []
    if dim == "route":
        route = str(event.attrs.get("route", "")) if event.attrs else ""
        return [route] if route else []
    if dim == "user":
        uid = event.actor.user_id
        return [uid] if uid else []
    if dim == "caller":
        c = event.actor.caller_identity
        return [c] if c else []
    return []


def _metric_dim(metric: str, subject_dim: str) -> str:
    """Map rule metric to the window_count dim string (bump_counters keys)."""
    if metric == "errors":
        return "errors"
    if metric == "auth_failures":
        return "errors"  # auth_failures tracked via error bucket for now
    return subject_dim  # "requests" → use subject_dim directly (ip/route/user/caller)


def _compare(n: int, comparator: str, threshold: int) -> bool:
    if comparator == ">":
        return n > threshold
    if comparator == ">=":
        return n >= threshold
    return False


class _FakeSink:
    """Minimal duck-typed sink used when no real sink is provided (best-effort)."""

    async def write_alert_audit(self, *_: Any, **__: Any) -> None: ...
    async def write_block_audit(self, *_: Any, **__: Any) -> None: ...


class _FakeActor:
    """Minimal actor for allowlist check when subject_type is not 'ip'."""

    def __init__(self, user_id: str | None) -> None:
        self.user_id = user_id
        self.caller_identity: str | None = None


class RuleEngine:
    """Evaluates enabled rules against recent window counts and raises alerts."""

    def __init__(
        self,
        *,
        hot: HotStore,
        sink: Any,  # EventSink or duck-typed object with write_alert_audit/write_block_audit
        delivery: AlertDelivery,
    ) -> None:
        self._hot = hot
        self._sink = sink
        self._delivery = delivery

    async def evaluate(self, events: list[MonitoringEvent], rules: list[Rule]) -> list[Alert]:
        """Evaluate all enabled rules against each distinct subject found in `events`.
        Returns all alerts raised. Errors are caught and logged — never propagated."""
        raised: list[Alert] = []
        if not events or not rules:
            return raised

        for rule in rules:
            if not rule.enabled:
                continue
            # Collect distinct subjects for this rule's dimension from the batch
            subjects: set[str] = set()
            for ev in events:
                subjects.update(_subjects_for_dim(rule.subject_dim, ev))

            for subject in subjects:
                try:
                    dim = _metric_dim(rule.metric, rule.subject_dim)
                    n = await self._hot.window_count(dim, subject, rule.window_s)
                except Exception:
                    log.debug(
                        "window_count error for rule %s subject %s", rule.id, subject, exc_info=True
                    )
                    continue

                if not _compare(n, rule.comparator, rule.threshold):
                    continue

                # Cooldown dedup (SET NX EX)
                try:
                    ok = await self._hot.cooldown_ok(rule.id, subject, rule.cooldown_s)
                except Exception:
                    log.debug("cooldown_ok error", exc_info=True)
                    ok = False  # conservative: skip alert if cooldown check fails

                if not ok:
                    continue

                # Determine subject_type for alert + potential block
                subject_type = rule.subject_dim if rule.subject_dim != "route" else "ip"

                alert = Alert(
                    id=str(uuid.uuid4()),
                    ts=int(time.time() * 1000),
                    rule_id=rule.id,
                    severity=rule.severity,
                    subject_type=subject_type,
                    subject=subject,
                    summary=f"{rule.name}: {n}/{rule.window_s}s [{rule.metric}]",
                    details={"window_count": n, "threshold": rule.threshold},
                )

                # Determine auto_action (FOUR gates)
                try:
                    auto_action = await self._resolve_auto_action(rule, subject_type, subject)
                    alert.auto_action = auto_action
                except Exception:
                    log.debug("auto_action resolve error", exc_info=True)
                    alert.auto_action = "block_skipped:error"

                # Raise alert (write to Redis + stream)
                try:
                    await self._hot.raise_alert(alert)
                except Exception:
                    log.warning("raise_alert failed for alert %s", alert.id, exc_info=True)

                # Audit trail — write alert to ClickHouse (best-effort)
                try:
                    await self._sink.write_alert_audit(alert)
                except Exception:
                    log.debug("write_alert_audit failed for alert %s", alert.id, exc_info=True)

                # Deliver (best-effort)
                try:
                    await self._delivery.deliver(alert)
                except Exception:
                    log.warning("alert delivery failed", exc_info=True)

                raised.append(alert)

        return raised

    async def _resolve_auto_action(self, rule: Rule, subject_type: str, subject: str) -> str:
        """Evaluate the four auto-block gates and execute or explain the skip."""
        # Gate 1: rule action must be "block"
        if rule.action != "block":
            return "block_skipped:action_alert"

        # Gate 2: per-rule auto_block_enabled (default False — dormant)
        if not rule.auto_block_enabled:
            return "block_skipped:auto_block_disabled"

        # Gate 3: global kill-switch must be on
        try:
            if not await self._hot.enforcement_enabled():
                return "block_skipped:enforcement_disabled"
        except Exception:
            return "block_skipped:enforcement_check_error"

        # Gate 4: subject must not be allowlisted
        try:
            ip_arg = subject if subject_type == "ip" else None
            actor_arg = _FakeActor(subject if subject_type != "ip" else None)
            if await self._hot.is_allowlisted(ip_arg, actor_arg):
                return "block_skipped:allowlisted"
        except Exception:
            return "block_skipped:allowlist_check_error"

        # All four gates passed → add TTL'd block
        until_ms = int(time.time() * 1000) + rule.block_ttl_s * 1000
        block = Block(
            subject_type=subject_type,  # type: ignore[arg-type]
            subject=subject,
            reason=f"auto-blocked by rule {rule.id}",
            mode="block",
            until=until_ms,
            source="rule",
            created_by=rule.id,
        )
        try:
            await self._hot.add_block(block)
        except Exception:
            log.warning("add_block failed (auto-block)", exc_info=True)
            return "block_skipped:add_block_error"

        # Audit write (best-effort)
        try:
            await self._sink.write_block_audit(block, action="block")
        except Exception:
            log.debug("write_block_audit failed", exc_info=True)

        return f"blocked:{rule.block_ttl_s}"

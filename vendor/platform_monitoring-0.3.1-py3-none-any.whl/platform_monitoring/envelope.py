from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, Field

ActorType = Literal["ui_user", "mcp", "api_key", "anonymous"]
GeoSource = Literal["cloudflare", "geolite2", "cloudflare+geolite2", "none"]


class Actor(BaseModel):
    type: ActorType = "anonymous"
    user_id: str | None = None
    org_id: str | None = None
    caller_identity: str | None = None
    api_key_id: str | None = None


class Geo(BaseModel):
    country: str | None = None
    city: str | None = None
    lat: float | None = None
    lon: float | None = None
    source: GeoSource = "none"


class MonitoringEvent(BaseModel):
    event_id: str
    event_type: str = "http.request"
    ts: int  # epoch milliseconds
    actor: Actor = Field(default_factory=Actor)
    source_ip: str | None = None
    geo: Geo = Field(default_factory=Geo)
    attrs: dict[str, Any] = Field(default_factory=dict)


# Column order MUST match schema/clickhouse/001_requests.sql exactly.
REQUEST_COLUMNS: list[str] = [
    "request_id",
    "ts",
    "event_type",
    "method",
    "route",
    "path",
    "status",
    "latency_ms",
    "resp_bytes",
    "actor_type",
    "user_id",
    "org_id",
    "caller_identity",
    "api_key_id",
    "ip",
    "ip_country",
    "ip_city",
    "ip_lat",
    "ip_lon",
    "geo_source",
    "user_agent",
    "referer",
    "was_blocked",
    "was_rate_limited",
    "block_reason",
]


def event_to_request_row(ev: MonitoringEvent) -> list[Any]:
    """Flatten a MonitoringEvent into a row matching REQUEST_COLUMNS order."""
    a = ev.attrs
    return [
        ev.event_id,
        datetime.fromtimestamp(ev.ts / 1000, tz=timezone.utc),
        ev.event_type,
        str(a.get("method", "")),
        str(a.get("route", "")),
        str(a.get("path", "")),
        int(a.get("status", 0)),
        int(a.get("latency_ms", 0)),
        int(a.get("resp_bytes", 0)),
        ev.actor.type,
        ev.actor.user_id or "",
        ev.actor.org_id or "",
        ev.actor.caller_identity or "",
        ev.actor.api_key_id or "",
        ev.source_ip or "",
        ev.geo.country or "",
        ev.geo.city or "",
        float(ev.geo.lat or 0.0),
        float(ev.geo.lon or 0.0),
        ev.geo.source,
        str(a.get("user_agent", "")),
        str(a.get("referer", "")),
        int(a.get("was_blocked", 0)),
        int(a.get("was_rate_limited", 0)),
        str(a.get("block_reason", "")),
    ]


__all__ = [
    "ActorType",
    "GeoSource",
    "Actor",
    "Geo",
    "MonitoringEvent",
    "REQUEST_COLUMNS",
    "event_to_request_row",
]

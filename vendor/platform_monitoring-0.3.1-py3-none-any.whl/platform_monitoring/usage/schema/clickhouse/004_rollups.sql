-- Daily LLM cost rollup
CREATE TABLE IF NOT EXISTS {db}.llm_cost_daily (
    event_date              Date,
    org_id                  Nullable(UUID),
    model                   LowCardinality(String),
    cost_usd_state          AggregateFunction(sum, Float64),
    input_tokens_state      AggregateFunction(sum, UInt64),
    output_tokens_state     AggregateFunction(sum, UInt64),
    cache_read_tokens_state AggregateFunction(sum, UInt64),
    calls_state             AggregateFunction(count)
) ENGINE = AggregatingMergeTree
ORDER BY (event_date, org_id, model)
SETTINGS allow_nullable_key = 1;

CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.llm_cost_daily_mv
TO {db}.llm_cost_daily AS
SELECT
    event_date,
    org_id,
    model,
    sumState(coalesce(total_cost_usd, 0))       AS cost_usd_state,
    sumState(toUInt64(input_tokens))             AS input_tokens_state,
    sumState(toUInt64(output_tokens))            AS output_tokens_state,
    sumState(toUInt64(cache_read_tokens))        AS cache_read_tokens_state,
    countState()                                  AS calls_state
FROM {db}.llm_calls
GROUP BY event_date, org_id, model;

-- Daily tool usage rollup
CREATE TABLE IF NOT EXISTS {db}.tool_usage_daily (
    event_date          Date,
    org_id              Nullable(UUID),
    tool_name           LowCardinality(String),
    calls_state         AggregateFunction(count),
    errors_state        AggregateFunction(count),
    duration_p95_state  AggregateFunction(quantiles(0.95), UInt32)
) ENGINE = AggregatingMergeTree
ORDER BY (event_date, org_id, tool_name)
SETTINGS allow_nullable_key = 1;

CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.tool_usage_daily_mv
TO {db}.tool_usage_daily AS
SELECT
    event_date,
    org_id,
    tool_name,
    countState()                             AS calls_state,
    countStateIf(status = 'error')           AS errors_state,
    quantilesState(0.95)(toUInt32(duration_ms)) AS duration_p95_state
FROM {db}.tool_calls
GROUP BY event_date, org_id, tool_name;

-- Daily step throughput rollup
CREATE TABLE IF NOT EXISTS {db}.step_throughput_daily (
    event_date          Date,
    org_id              Nullable(UUID),
    node_type           LowCardinality(Nullable(String)),
    succeeded_state     AggregateFunction(count),
    failed_state        AggregateFunction(count),
    skipped_state       AggregateFunction(count),
    duration_p95_state  AggregateFunction(quantiles(0.95), UInt32)
) ENGINE = AggregatingMergeTree
ORDER BY (event_date, org_id, node_type)
SETTINGS allow_nullable_key = 1;

CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.step_throughput_daily_mv
TO {db}.step_throughput_daily AS
SELECT
    event_date,
    org_id,
    node_type,
    countStateIf(status = 'succeeded')          AS succeeded_state,
    countStateIf(status = 'failed')             AS failed_state,
    countStateIf(status = 'skipped')            AS skipped_state,
    quantilesState(0.95)(toUInt32(duration_ms)) AS duration_p95_state
FROM {db}.step_runs
GROUP BY event_date, org_id, node_type;

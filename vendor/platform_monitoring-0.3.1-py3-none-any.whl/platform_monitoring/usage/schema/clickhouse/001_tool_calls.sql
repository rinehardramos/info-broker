CREATE TABLE IF NOT EXISTS {db}.tool_calls (
    event_id        UUID,
    ts              DateTime64(3, 'UTC'),
    event_date      Date MATERIALIZED toDate(ts),
    user_id         Nullable(UUID),
    org_id          Nullable(UUID),
    caller_identity Nullable(String),
    run_id          Nullable(UUID),
    session_id      Nullable(UUID),
    node_id         Nullable(UUID),
    tool_name       LowCardinality(String),
    node_type       LowCardinality(Nullable(String)),
    status          LowCardinality(String),
    duration_ms     UInt32,
    result_count    Nullable(Int32),
    error_kind      LowCardinality(Nullable(String))
) ENGINE = MergeTree
ORDER BY (event_date, org_id, tool_name, ts)
TTL event_date + INTERVAL {usage_retention_days} DAY DELETE
SETTINGS index_granularity = 8192, allow_nullable_key = 1;

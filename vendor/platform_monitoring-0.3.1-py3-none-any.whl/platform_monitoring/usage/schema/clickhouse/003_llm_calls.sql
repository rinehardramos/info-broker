CREATE TABLE IF NOT EXISTS {db}.llm_calls (
    event_id                UUID,
    ts                      DateTime64(3, 'UTC'),
    event_date              Date MATERIALIZED toDate(ts),
    user_id                 Nullable(UUID),
    org_id                  Nullable(UUID),
    caller_identity         Nullable(String),
    run_id                  Nullable(UUID),
    session_id              Nullable(UUID),
    node_id                 Nullable(UUID),
    model                   LowCardinality(String),
    provider                LowCardinality(String),
    status                  LowCardinality(String),
    input_tokens            UInt32,
    output_tokens           UInt32,
    cache_creation_tokens   UInt32,
    cache_read_tokens       UInt32,
    duration_ms             UInt32,
    num_turns               Nullable(UInt16),
    phase                   Nullable(String),
    total_cost_usd          Nullable(Float64),
    cost_source             LowCardinality(String),
    pricing_id              Nullable(UUID)
) ENGINE = MergeTree
ORDER BY (event_date, org_id, model, ts)
TTL event_date + INTERVAL {usage_retention_days} DAY DELETE
SETTINGS index_granularity = 8192, allow_nullable_key = 1;

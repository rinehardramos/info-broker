CREATE TABLE IF NOT EXISTS {db}.step_runs (
    event_id        UUID,
    ts              DateTime64(3, 'UTC'),
    event_date      Date MATERIALIZED toDate(ts),
    user_id         Nullable(UUID),
    org_id          Nullable(UUID),
    caller_identity Nullable(String),
    run_id          Nullable(UUID),
    session_id      Nullable(UUID),
    node_id         Nullable(UUID),
    node_type       LowCardinality(Nullable(String)),
    status          LowCardinality(String),
    item_count      UInt32,
    duration_ms     UInt32,
    error_kind      LowCardinality(Nullable(String))
) ENGINE = MergeTree
ORDER BY (event_date, org_id, node_type, ts)
TTL event_date + INTERVAL {usage_retention_days} DAY DELETE
SETTINGS index_granularity = 8192, allow_nullable_key = 1;

# src/platform_monitoring/usage/emitter.py
"""UsageEmitter — fire-and-forget XADD to the mon:usage Redis stream.

Mirrors the MonitoringMiddleware emit pattern: errors are swallowed and counted
so orchestration is never blocked or failed by telemetry.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from redis.asyncio import Redis as AsyncRedis

from platform_monitoring.usage.events import (
    LlmCallEvent,
    StepRunEvent,
    ToolCallEvent,
    UsageEventBase,
)

log = logging.getLogger("platform_monitoring.usage.emitter")

_emit_errors_total = 0  # simple in-process counter; Prometheus can scrape via a gauge hook


class UsageEmitter:
    """Serialise a UsageEvent and XADD it to a Redis stream (fire-and-forget).

    Single instance per process; share the existing monitoring Redis connection.
    """

    def __init__(
        self,
        redis: AsyncRedis,
        *,
        stream: str = "mon:usage",
        maxlen: int = 100_000,
    ) -> None:
        self._r = redis
        self._stream = stream
        self._maxlen = maxlen
        self._task_refs: set[asyncio.Task[None]] = set()

    async def emit(self, event: UsageEventBase) -> None:
        """Serialize event to JSON and XADD with MAXLEN ~maxlen cap. Swallows all errors."""
        try:
            data = event.model_dump_json()
            await self._r.xadd(
                self._stream,
                {"data": data},
                maxlen=self._maxlen,
                approximate=True,
            )
        except Exception:
            global _emit_errors_total
            _emit_errors_total += 1
            log.debug("UsageEmitter.emit failed (swallowed)", exc_info=True)

    def emit_nowait(self, event: UsageEventBase) -> None:
        """Schedule emit as a background task; retains a reference to prevent GC."""
        task: asyncio.Task[None] = asyncio.ensure_future(self.emit(event))
        self._task_refs.add(task)
        task.add_done_callback(self._task_refs.discard)

    async def emit_tool_call(self, **kwargs: Any) -> None:
        """Convenience wrapper: construct ToolCallEvent from kwargs and emit."""
        ev = ToolCallEvent(**kwargs)
        await self.emit(ev)

    async def emit_step_run(self, **kwargs: Any) -> None:
        """Convenience wrapper: construct StepRunEvent from kwargs and emit."""
        ev = StepRunEvent(**kwargs)
        await self.emit(ev)

    async def emit_llm_call(self, **kwargs: Any) -> None:
        """Convenience wrapper: construct LlmCallEvent from kwargs and emit."""
        ev = LlmCallEvent(**kwargs)
        await self.emit(ev)


__all__ = ["UsageEmitter"]

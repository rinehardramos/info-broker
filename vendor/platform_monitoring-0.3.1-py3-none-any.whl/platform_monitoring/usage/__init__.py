"""Usage telemetry domain — tool_call / step_run / llm_call events."""

"""Pydantic v2 event models for the usage telemetry domain.

These are siblings of MonitoringEvent (the HTTP-request envelope), not subclasses.
All three concrete types share UsageEventBase. Epoch-ms timestamps throughout.
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, model_validator


class Actor(BaseModel):
    """Identity context threaded via X-Caller headers / vault resolution.

    All fields are nullable so anonymous / system events still record.
    NEVER put raw API keys here — only opaque UUIDs and the caller_identity string.
    """

    user_id: UUID | None = None
    org_id: UUID | None = None
    caller_identity: str | None = None


class UsageEventBase(BaseModel):
    """Shared fields for all three usage event types."""

    event_id: UUID = Field(default_factory=uuid4)
    ts: int  # epoch milliseconds
    kind: Literal["tool_call", "step_run", "llm_call"]
    actor: Actor
    run_id: UUID | None = None
    session_id: UUID | None = None
    node_id: UUID | None = None


class ToolCallEvent(UsageEventBase):
    """Emitted once per MCP tool-call completion."""

    kind: Literal["tool_call"] = "tool_call"
    tool_name: str
    node_type: str | None = None
    status: Literal["ok", "error"]
    duration_ms: int
    result_count: int | None = None
    error_kind: str | None = None  # short class name, e.g. "TimeoutError" — NOT the raw message

    @model_validator(mode="after")
    def _validate_duration(self) -> "ToolCallEvent":
        if self.duration_ms < 0:
            raise ValueError(f"duration_ms must be >= 0, got {self.duration_ms}")
        return self


class StepRunEvent(UsageEventBase):
    """Emitted once per pipeline node completion (succeeded / failed / skipped)."""

    kind: Literal["step_run"] = "step_run"
    node_type: str | None = None
    status: Literal["succeeded", "failed", "skipped"]
    item_count: int = 0
    duration_ms: int  # finished_at_ms - started_at_ms
    error_kind: str | None = None

    @model_validator(mode="after")
    def _validate_duration(self) -> "StepRunEvent":
        if self.duration_ms < 0:
            raise ValueError(f"duration_ms must be >= 0, got {self.duration_ms}")
        return self


class LlmCallEvent(UsageEventBase):
    """Emitted once per LLM completion (subscription brain or direct model call)."""

    kind: Literal["llm_call"] = "llm_call"
    model: str
    provider: str  # 'anthropic' | 'openai' | 'openrouter' | …
    status: Literal["ok", "error"]
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    duration_ms: int = 0
    num_turns: int | None = None
    phase: str | None = None
    total_cost_usd: float | None = None  # None when cost_source == 'unknown_model'
    cost_source: Literal["subscription", "estimated", "unknown_model"]
    pricing_id: UUID | None = None  # set iff cost_source == 'estimated'

    @model_validator(mode="after")
    def _validate_cost_invariants(self) -> "LlmCallEvent":
        if self.duration_ms < 0:
            raise ValueError(f"duration_ms must be >= 0, got {self.duration_ms}")
        if self.cost_source == "estimated" and self.pricing_id is None:
            raise ValueError("pricing_id must be set when cost_source == 'estimated'")
        if self.cost_source == "subscription" and self.pricing_id is not None:
            raise ValueError("pricing_id must be NULL when cost_source == 'subscription'")
        if self.cost_source == "unknown_model" and self.total_cost_usd is not None:
            raise ValueError("total_cost_usd must be NULL when cost_source == 'unknown_model'")
        return self


# Union type used for runtime routing
UsageEvent = ToolCallEvent | StepRunEvent | LlmCallEvent

__all__ = [
    "Actor",
    "UsageEventBase",
    "ToolCallEvent",
    "StepRunEvent",
    "LlmCallEvent",
    "UsageEvent",
]

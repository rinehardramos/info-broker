import asyncio
import logging
import signal

from platform_monitoring.envelope import MonitoringEvent
from platform_monitoring.ports.event_sink import EventSink
from platform_monitoring.ports.hot_store import HotStore, get_hot_store

log = logging.getLogger("platform_monitoring.worker")


class IngestionWorker:
    """Drains the Redis stream into the EventSink and bumps hot counters."""

    def __init__(
        self, *, hot_store: HotStore, sink: EventSink, batch_size: int = 500, block_ms: int = 1000
    ) -> None:
        self._hot = hot_store
        self._sink = sink
        self._batch = batch_size
        self._block_ms = block_ms
        self._stop = asyncio.Event()

    async def _handle(self, batch: list[tuple[str, MonitoringEvent]]) -> int:
        if not batch:
            return 0
        events = [ev for _, ev in batch]
        # write_batch first; only ack if it succeeds (at-least-once delivery).
        await self._sink.write_batch(events)
        for ev in events:
            try:
                await self._hot.bump_counters(ev)
            except Exception:  # counters are best-effort; never block ingestion
                log.warning("bump_counters failed", exc_info=True)
        await self._hot.ack([sid for sid, _ in batch])
        return len(batch)

    async def process_once(self) -> int:
        """Read one batch of new messages ('>') and process it."""
        batch = await self._hot.read_batch(count=self._batch, block_ms=self._block_ms)
        return await self._handle(batch)

    async def process_pending(self) -> int:
        """Reclaim and process this consumer's pending (unacked) messages."""
        batch = await self._hot.read_pending(count=self._batch)
        return await self._handle(batch)

    async def run_forever(self) -> None:
        await self._hot.ensure_group()
        # Reclaim ALL messages delivered-but-unacked by a previous crash of this
        # consumer before processing new ones (at-least-once recovery). Drain the
        # pending list batch-by-batch until empty so a backlog larger than one
        # batch is fully recovered in a single startup.
        try:
            while not self._stop.is_set():
                reclaimed = await self.process_pending()
                if not reclaimed:
                    break
                log.info("reclaimed %d pending message(s) at startup", reclaimed)
        except Exception:
            log.exception("startup pending reclaim failed; continuing")
        log.info("monitoring worker started")
        while not self._stop.is_set():
            try:
                await self.process_once()
            except Exception:  # one bad batch must not kill the loop
                log.exception("ingestion batch failed; will retry")
                await asyncio.sleep(1.0)

    def stop(self) -> None:
        self._stop.set()


async def _amain() -> None:
    from platform_monitoring.adapters.clickhouse_sink import ClickHouseSink
    from platform_monitoring.adapters.redis_hot_store import RedisHotStore
    from platform_monitoring.ports.event_sink import register_event_sink
    from platform_monitoring.ports.hot_store import register_hot_store
    from platform_monitoring.settings import MonitoringSettings

    logging.basicConfig(level=logging.INFO)
    s = MonitoringSettings()  # type: ignore[call-arg]
    register_hot_store(RedisHotStore(s.monitoring_redis_url, stream_maxlen=s.stream_maxlen))
    sink = ClickHouseSink(
        s.clickhouse_url, database=s.clickhouse_database, raw_retention_days=s.raw_retention_days
    )
    await sink.bootstrap_schema()
    register_event_sink(sink)

    hot = get_hot_store()
    worker = IngestionWorker(hot_store=hot, sink=sink)
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, worker.stop)
    try:
        await worker.run_forever()
    finally:
        await hot.aclose()
        await sink.aclose()


def main() -> None:
    asyncio.run(_amain())


if __name__ == "__main__":
    main()

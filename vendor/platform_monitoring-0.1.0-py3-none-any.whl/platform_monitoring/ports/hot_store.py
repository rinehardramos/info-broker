from typing import Protocol, runtime_checkable

from platform_monitoring.envelope import MonitoringEvent


@runtime_checkable
class HotStore(Protocol):
    """Real-time hot layer: stream buffer, counters. (denylist/rules added in Phase 2)"""

    async def emit(self, event: MonitoringEvent) -> None: ...
    async def ensure_group(self) -> None: ...
    async def read_batch(self, count: int, block_ms: int) -> list[tuple[str, MonitoringEvent]]: ...
    async def read_pending(self, count: int) -> list[tuple[str, MonitoringEvent]]: ...
    async def ack(self, ids: list[str]) -> None: ...
    async def bump_counters(self, event: MonitoringEvent) -> None: ...
    async def window_count(self, dim: str, ident: str, window_s: int) -> int: ...
    async def aclose(self) -> None: ...


_hot: HotStore | None = None


def register_hot_store(impl: HotStore) -> None:
    global _hot
    _hot = impl


def get_hot_store() -> HotStore:
    if _hot is None:
        raise RuntimeError(
            "No HotStore registered. Call register_hot_store(RedisHotStore(...)) at startup."
        )
    return _hot


def reset_hot_store() -> None:
    global _hot
    _hot = None

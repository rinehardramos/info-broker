# src/platform_monitoring/ports/event_sink.py
from typing import Protocol, runtime_checkable

from platform_monitoring.envelope import MonitoringEvent
from platform_monitoring.query_models import (
    ActorSpec,
    ActorSummary,
    GeoBucket,
    GeoSpec,
    OverviewResult,
    OverviewSpec,
    Page,
    Point,
    RequestFilter,
    RequestRow,
    TimeseriesSpec,
    TopRow,
    TopSpec,
)


@runtime_checkable
class EventSink(Protocol):
    """Durable detail store + historical analytics. Phase-1 write methods plus
    six read methods added in Plan 2. Implementations must provide all methods."""

    # ── Write (Plan 1) ────────────────────────────────────────────────────────
    async def bootstrap_schema(self) -> None: ...
    async def write_batch(self, events: list[MonitoringEvent]) -> None: ...
    async def aclose(self) -> None: ...

    # ── Read (Plan 2) ─────────────────────────────────────────────────────────
    async def query_overview(self, spec: OverviewSpec) -> OverviewResult: ...
    async def query_timeseries(self, spec: TimeseriesSpec) -> list[Point]: ...
    async def query_top(self, spec: TopSpec) -> list[TopRow]: ...
    async def query_geo(self, spec: GeoSpec) -> list[GeoBucket]: ...
    async def query_requests(self, filt: RequestFilter) -> Page[RequestRow]: ...
    async def query_actor(self, spec: ActorSpec) -> ActorSummary: ...


_sink: EventSink | None = None


def register_event_sink(impl: EventSink) -> None:
    global _sink
    _sink = impl


def get_event_sink() -> EventSink:
    if _sink is None:
        raise RuntimeError(
            "No EventSink registered. Call register_event_sink(ClickHouseSink(...)) at startup."
        )
    return _sink


def reset_event_sink() -> None:
    global _sink
    _sink = None

from typing import Protocol, runtime_checkable

from platform_monitoring.envelope import Geo


@runtime_checkable
class GeoResolver(Protocol):
    """Resolve an IP address to a Geo record. May be called on every request;
    implementations SHOULD cache results in an in-process LRU."""

    async def resolve(self, ip: str) -> Geo: ...


_resolver: GeoResolver | None = None


def register_geo_resolver(impl: GeoResolver) -> None:
    global _resolver
    _resolver = impl


def get_geo_resolver() -> GeoResolver:
    if _resolver is None:
        raise RuntimeError("No GeoResolver registered. Call register_geo_resolver(...) at startup.")
    return _resolver


def reset_geo_resolver() -> None:
    global _resolver
    _resolver = None

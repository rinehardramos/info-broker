"""Swappable ports (ADR-001). Phase-1 subset; extended in later plans."""

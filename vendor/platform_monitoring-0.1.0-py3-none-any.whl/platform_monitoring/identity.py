"""Best-effort actor identification — NEVER raises, NEVER returns 401.

Resolution order:
  1. JWT Bearer token (via injected decoder callable) → ui_user
  2. X-Caller-Identity header → mcp
  3. X-API-Key-Id header → api_key
  4. Anonymous fallback

The JWT decoder is injected by the host so the library remains auth-agnostic.
It must accept a raw token str and return a dict with at least 'sub'; it may
also return 'org_id'. Any exception causes a silent fall-through.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from platform_monitoring.envelope import Actor

log = logging.getLogger("platform_monitoring.identity")


async def identify_actor(
    headers: dict[str, str],
    *,
    jwt_decoder: Callable[[str], dict[str, Any]] | None,
) -> Actor:
    """Return the best-effort Actor for a request. Never raises."""
    h = {k.lower(): v for k, v in headers.items()}

    # ── 1. JWT ────────────────────────────────────────────────────────────────
    auth = h.get("authorization", "")
    if jwt_decoder is not None and auth.startswith("Bearer "):
        token = auth[len("Bearer ") :]
        try:
            claims = jwt_decoder(token)
            return Actor(
                type="ui_user",
                user_id=str(claims.get("sub") or ""),
                org_id=str(claims.get("org_id") or "") or None,
            )
        except Exception:
            log.debug("JWT decode failed; continuing actor resolution", exc_info=True)

    # ── 2. MCP X-Caller-Identity ─────────────────────────────────────────────
    caller_identity = h.get("x-caller-identity")
    if caller_identity:
        return Actor(type="mcp", caller_identity=caller_identity)

    # ── 3. API-key id header ──────────────────────────────────────────────────
    api_key_id = h.get("x-api-key-id")
    if api_key_id:
        return Actor(type="api_key", api_key_id=api_key_id)

    # ── 4. Anonymous ──────────────────────────────────────────────────────────
    return Actor(type="anonymous")

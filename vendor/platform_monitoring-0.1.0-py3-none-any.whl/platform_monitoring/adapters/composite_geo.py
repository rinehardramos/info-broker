import ipaddress

from platform_monitoring.envelope import Geo
from platform_monitoring.ports.geo_resolver import GeoResolver

_PRIVATE_NETS = [
    ipaddress.ip_network(cidr)
    for cidr in (
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "127.0.0.0/8",
        "::1/128",
        "fc00::/7",
        "169.254.0.0/16",
    )
]


def _is_private(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return any(addr in net for net in _PRIVATE_NETS)
    except ValueError:
        return False


class CompositeGeo:
    """CF headers first, GeoLite2 fallback. Private/LAN IPs → source='none'."""

    def __init__(self, *, cf_resolver: GeoResolver, lite2_resolver: GeoResolver) -> None:
        self._cf = cf_resolver
        self._lite2 = lite2_resolver

    async def resolve(self, ip: str) -> Geo:
        if _is_private(ip):
            return Geo(source="none")
        cf_result = await self._cf.resolve(ip)
        if cf_result.country:
            return cf_result
        return await self._lite2.resolve(ip)

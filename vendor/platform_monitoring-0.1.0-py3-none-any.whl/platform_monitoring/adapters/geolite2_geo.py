import asyncio
import ipaddress
from typing import Any, cast

import maxminddb

from platform_monitoring.envelope import Geo

_PRIVATE_NETS = [
    ipaddress.ip_network(cidr)
    for cidr in (
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "127.0.0.0/8",
        "::1/128",
        "fc00::/7",
        "169.254.0.0/16",
    )
]


def _is_private(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return any(addr in net for net in _PRIVATE_NETS)
    except ValueError:
        return False


class GeoLite2Geo:
    """Offline geo lookup using a MaxMind GeoLite2 .mmdb file.
    Opens the reader lazily; keeps it open for the process lifetime."""

    def __init__(self, *, db_path: str) -> None:
        self._path = db_path
        self._reader: maxminddb.Reader | None = None

    def _open(self) -> maxminddb.Reader:
        if self._reader is None:
            self._reader = maxminddb.open_database(self._path)
        return self._reader

    async def resolve(self, ip: str) -> Geo:
        if _is_private(ip):
            return Geo(source="none")
        try:
            reader = self._open()
            raw = await asyncio.to_thread(reader.get, ip)
            record: dict[str, Any] | None = cast(dict[str, Any] | None, raw)
        except Exception:
            return Geo(source="none")
        if not record:
            return Geo(source="none")
        country = (record.get("country") or {}).get("iso_code") or None
        city_names = (record.get("city") or {}).get("names") or {}
        city = city_names.get("en") or None
        loc = record.get("location") or {}
        lat: float | None = loc.get("latitude")
        lon: float | None = loc.get("longitude")
        return Geo(country=country, city=city, lat=lat, lon=lon, source="geolite2")

    def close(self) -> None:
        if self._reader is not None:
            self._reader.close()
            self._reader = None

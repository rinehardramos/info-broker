from platform_monitoring.envelope import Geo


class CloudflareGeo:
    """Reads CF-IP* headers injected by Cloudflare. Stateless — a new instance
    is created per request from the ASGI scope headers."""

    def __init__(self, *, headers: dict[str, str]) -> None:
        self._h = {k.lower(): v for k, v in headers.items()}

    async def resolve(self, ip: str) -> Geo:  # noqa: ARG002 (ip unused; CF gives it in headers)
        country = self._h.get("cf-ipcountry") or None
        city = self._h.get("cf-ipcity") or None
        try:
            lat: float | None = float(self._h["cf-iplatitude"])
        except (KeyError, ValueError):
            lat = None
        try:
            lon: float | None = float(self._h["cf-iplongitude"])
        except (KeyError, ValueError):
            lon = None
        return Geo(country=country, city=city, lat=lat, lon=lon, source="cloudflare")

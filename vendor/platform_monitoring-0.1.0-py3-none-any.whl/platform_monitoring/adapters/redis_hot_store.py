import time

import redis.asyncio as redis
from redis.exceptions import ResponseError

from platform_monitoring.envelope import MonitoringEvent


class RedisHotStore:
    """Redis-backed HotStore: stream buffer + real-time counters."""

    def __init__(
        self,
        url: str,
        *,
        stream: str = "mon:events",
        group: str = "mon:ingest",
        consumer: str = "worker-1",
        stream_maxlen: int = 1_000_000,
    ) -> None:
        self._r = redis.from_url(url, decode_responses=True)
        self._stream = stream
        self._group = group
        self._consumer = consumer
        self._maxlen = stream_maxlen

    async def emit(self, event: MonitoringEvent) -> None:
        await self._r.xadd(
            self._stream,
            {"data": event.model_dump_json()},
            maxlen=self._maxlen,
            approximate=True,
        )

    async def ensure_group(self) -> None:
        try:
            await self._r.xgroup_create(self._stream, self._group, id="0", mkstream=True)
        except ResponseError as e:
            if "BUSYGROUP" not in str(e):
                raise

    async def read_batch(self, count: int, block_ms: int) -> list[tuple[str, MonitoringEvent]]:
        resp = await self._r.xreadgroup(
            self._group, self._consumer, {self._stream: ">"}, count=count, block=block_ms
        )
        if not resp:
            return []
        out: list[tuple[str, MonitoringEvent]] = []
        for _stream_name, entries in resp:
            for entry_id, fields in entries:
                out.append((entry_id, MonitoringEvent.model_validate_json(fields["data"])))
        return out

    async def read_pending(self, count: int) -> list[tuple[str, MonitoringEvent]]:
        # Read this consumer's already-delivered-but-unacked messages (id "0").
        resp = await self._r.xreadgroup(
            self._group, self._consumer, {self._stream: "0"}, count=count
        )
        if not resp:
            return []
        out: list[tuple[str, MonitoringEvent]] = []
        for _stream_name, entries in resp:
            for entry_id, fields in entries:
                out.append((entry_id, MonitoringEvent.model_validate_json(fields["data"])))
        return out

    async def ack(self, ids: list[str]) -> None:
        if ids:
            await self._r.xack(self._stream, self._group, *ids)

    async def bump_counters(self, event: MonitoringEvent) -> None:
        ip = event.source_ip
        now_s = event.ts // 1000
        minute = now_s // 60
        pipe = self._r.pipeline()
        # Global all-events counter — always incremented, regardless of source_ip
        all_key = f"mon:cnt:all:all:{minute}"
        pipe.incr(all_key)
        pipe.expire(all_key, 120)
        if ip:
            top_key = f"mon:top:ip:{minute}"
            pipe.zincrby(top_key, 1, ip)
            pipe.expire(top_key, 3600)
            hll_key = f"mon:hll:uniq:{minute}"
            pipe.pfadd(hll_key, ip)
            pipe.expire(hll_key, 3600)
            win_key = f"mon:cnt:ip:{ip}:{minute}"
            pipe.incr(win_key)
            pipe.expire(win_key, 120)
        await pipe.execute()

    async def window_count(self, dim: str, ident: str, window_s: int) -> int:
        # Phase-1: current 60s bucket only (Phase-2 adds true sliding windows).
        # NOTE: this buckets on wall-clock time, while bump_counters buckets on the
        # event's own ts. The Phase-2 rule engine must reconcile the two clocks.
        minute = int(time.time()) // 60
        val = await self._r.get(f"mon:cnt:{dim}:{ident}:{minute}")
        return int(val) if val else 0

    async def aclose(self) -> None:
        await self._r.aclose()

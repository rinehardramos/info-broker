-- 005_req_by_actor.sql
-- Per-actor rollup (by actor_type + user_id/caller_identity/api_key_id).
CREATE TABLE IF NOT EXISTS {db}.req_by_actor (
    actor_type       LowCardinality(String),
    actor_id         String,        -- user_id | caller_identity | api_key_id | "anonymous"
    minute           DateTime,
    requests         SimpleAggregateFunction(sum, UInt64),
    errors_4xx       SimpleAggregateFunction(sum, UInt64),
    errors_5xx       SimpleAggregateFunction(sum, UInt64),
    latency_state    AggregateFunction(quantiles(0.5, 0.95, 0.99), UInt32)
)
ENGINE = AggregatingMergeTree
ORDER BY (actor_type, actor_id, minute);

CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.req_by_actor_mv TO {db}.req_by_actor AS
SELECT
    actor_type,
    multiIf(
        actor_type = 'ui_user',  user_id,
        actor_type = 'mcp',      caller_identity,
        actor_type = 'api_key',  api_key_id,
        'anonymous'
    )                                                          AS actor_id,
    toStartOfMinute(ts)                                        AS minute,
    count()                                                    AS requests,
    countIf(status >= 400 AND status < 500)                    AS errors_4xx,
    countIf(status >= 500)                                     AS errors_5xx,
    quantilesState(0.5, 0.95, 0.99)(latency_ms)               AS latency_state
FROM {db}.requests
GROUP BY actor_type, actor_id, minute;

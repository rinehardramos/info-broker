-- 001_requests.sql
CREATE DATABASE IF NOT EXISTS {db};

CREATE TABLE IF NOT EXISTS {db}.requests (
    request_id       String,
    ts               DateTime64(3),
    event_type       LowCardinality(String) DEFAULT 'http.request',
    method           LowCardinality(String),
    route            String,
    path             String,
    status           UInt16,
    latency_ms       UInt32,
    resp_bytes       UInt32,
    actor_type       LowCardinality(String),
    user_id          String,
    org_id           String,
    caller_identity  String,
    api_key_id       String,
    ip               String,
    ip_country       LowCardinality(String),
    ip_city          String,
    ip_lat           Float32,
    ip_lon           Float32,
    geo_source       LowCardinality(String),
    user_agent       String,
    referer          String,
    was_blocked      UInt8,
    was_rate_limited UInt8,
    block_reason     LowCardinality(String)
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(ts)
ORDER BY (ts, actor_type, ip)
TTL toDateTime(ts) + INTERVAL {raw_retention_days} DAY DELETE
SETTINGS index_granularity = 8192;

-- 004_req_by_country.sql
-- Per-country rollup for the geo map.
CREATE TABLE IF NOT EXISTS {db}.req_by_country (
    ip_country       LowCardinality(String),
    minute           DateTime,
    requests         SimpleAggregateFunction(sum, UInt64),
    errors_4xx       SimpleAggregateFunction(sum, UInt64),
    errors_5xx       SimpleAggregateFunction(sum, UInt64),
    uniq_ip_state    AggregateFunction(uniq, String)
)
ENGINE = AggregatingMergeTree
ORDER BY (ip_country, minute);

CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.req_by_country_mv TO {db}.req_by_country AS
SELECT
    ip_country,
    toStartOfMinute(ts)                                       AS minute,
    count()                                                   AS requests,
    countIf(status >= 400 AND status < 500)                   AS errors_4xx,
    countIf(status >= 500)                                    AS errors_5xx,
    uniqState(ip)                                             AS uniq_ip_state
FROM {db}.requests
GROUP BY ip_country, minute;

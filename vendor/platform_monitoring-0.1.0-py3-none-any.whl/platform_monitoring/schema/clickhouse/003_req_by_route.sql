-- 003_req_by_route.sql
-- Per-route rollup: request counts, error rates, latency distribution.
CREATE TABLE IF NOT EXISTS {db}.req_by_route (
    route            String,
    minute           DateTime,
    requests         SimpleAggregateFunction(sum, UInt64),
    errors_4xx       SimpleAggregateFunction(sum, UInt64),
    errors_5xx       SimpleAggregateFunction(sum, UInt64),
    latency_state    AggregateFunction(quantiles(0.5, 0.95, 0.99), UInt32),
    uniq_ip_state    AggregateFunction(uniq, String)
)
ENGINE = AggregatingMergeTree
ORDER BY (route, minute);

CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.req_by_route_mv TO {db}.req_by_route AS
SELECT
    route,
    toStartOfMinute(ts)                                       AS minute,
    count()                                                   AS requests,
    countIf(status >= 400 AND status < 500)                   AS errors_4xx,
    countIf(status >= 500)                                    AS errors_5xx,
    quantilesState(0.5, 0.95, 0.99)(latency_ms)              AS latency_state,
    uniqState(ip)                                             AS uniq_ip_state
FROM {db}.requests
GROUP BY route, minute;

# src/platform_monitoring/query_models.py
"""Typed input specs and output shapes for EventSink query methods and QueryService."""

from __future__ import annotations

from typing import Generic, Literal, TypeVar

from pydantic import BaseModel, Field

Granularity = Literal["minute", "hour", "day"]
TopDimension = Literal["ip", "route", "country", "actor"]
ActorTypeFilter = Literal["ui_user", "mcp", "api_key", "anonymous"]

T = TypeVar("T")


# ── Input specs ───────────────────────────────────────────────────────────────


class TimeseriesSpec(BaseModel):
    from_ts: int  # epoch ms
    to_ts: int  # epoch ms
    granularity: Granularity = "minute"
    actor_type: ActorTypeFilter | None = None
    country: str | None = None
    route: str | None = None


class TopSpec(BaseModel):
    from_ts: int
    to_ts: int
    dimension: TopDimension = "ip"
    limit: int = Field(default=20, ge=1, le=500)
    actor_type: ActorTypeFilter | None = None


class GeoSpec(BaseModel):
    from_ts: int
    to_ts: int
    limit: int = Field(default=200, ge=1, le=1000)


class RequestFilter(BaseModel):
    from_ts: int
    to_ts: int
    actor_type: ActorTypeFilter | None = None
    country: str | None = None
    route: str | None = None
    ip: str | None = None
    status: int | None = None
    limit: int = Field(default=100, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)


class OverviewSpec(BaseModel):
    from_ts: int
    to_ts: int


class ActorSpec(BaseModel):
    actor_type: ActorTypeFilter
    actor_id: str  # user_id | caller_identity | api_key_id
    from_ts: int
    to_ts: int


# ── Output shapes ─────────────────────────────────────────────────────────────


class Point(BaseModel):
    ts: int  # epoch ms (bucket start)
    requests: int
    errors_4xx: int = 0
    errors_5xx: int = 0
    p50_ms: float | None = None
    p95_ms: float | None = None
    p99_ms: float | None = None
    unique_ips: int | None = None


class TopRow(BaseModel):
    label: str  # IP / route / country / actor_id
    requests: int
    errors_4xx: int = 0
    errors_5xx: int = 0
    p95_ms: float | None = None


class GeoBucket(BaseModel):
    country: str
    requests: int
    errors_4xx: int = 0
    errors_5xx: int = 0
    unique_ips: int | None = None


class RequestRow(BaseModel):
    request_id: str
    ts: int  # epoch ms
    method: str
    route: str
    path: str
    status: int
    latency_ms: int
    resp_bytes: int
    actor_type: str
    actor_id: str  # resolved display id
    ip: str
    country: str | None
    city: str | None
    geo_source: str
    user_agent: str
    was_blocked: bool
    was_rate_limited: bool
    block_reason: str


class ActorSummary(BaseModel):
    actor_type: str
    actor_id: str
    requests_total: int
    errors_4xx: int = 0
    errors_5xx: int = 0
    p95_ms: float | None = None
    first_seen_ts: int | None = None
    last_seen_ts: int | None = None
    top_routes: list[TopRow] = Field(default_factory=list)


class OverviewResult(BaseModel):
    requests_total: int
    requests_1m: int  # last 60s (from Redis hot)
    error_rate: float  # fraction 0.0–1.0
    p95_latency_ms: float | None = None
    unique_ips: int  # from ClickHouse window
    unique_ips_hll: int  # from Redis HLL (more recent)
    blocked_total: int
    open_alerts: int


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    limit: int
    offset: int

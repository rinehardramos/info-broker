from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MonitoringSettings(BaseSettings):
    """Environment-driven configuration for platform-monitoring."""

    model_config = SettingsConfigDict(extra="ignore", case_sensitive=False)

    enabled: bool = Field(default=True, alias="MONITORING_ENABLED")
    clickhouse_url: str = Field(alias="CLICKHOUSE_URL")
    monitoring_redis_url: str = Field(alias="MONITORING_REDIS_URL")
    clickhouse_database: str = Field(default="mon", alias="MON_CLICKHOUSE_DATABASE")
    raw_retention_days: int = Field(default=30, alias="MON_RAW_RETENTION_DAYS")
    stream_maxlen: int = Field(default=1_000_000, alias="MON_STREAM_MAXLEN")

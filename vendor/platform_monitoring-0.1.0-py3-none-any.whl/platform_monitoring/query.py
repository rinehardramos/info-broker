# src/platform_monitoring/query.py
"""QueryService: blends ClickHouse history with Redis hot reads for /overview,
and delegates other queries straight to the EventSink."""

from __future__ import annotations

import logging
import time

from platform_monitoring.ports.event_sink import EventSink
from platform_monitoring.ports.hot_store import HotStore
from platform_monitoring.query_models import (
    ActorSpec,
    ActorSummary,
    GeoBucket,
    GeoSpec,
    OverviewResult,
    OverviewSpec,
    Page,
    Point,
    RequestFilter,
    RequestRow,
    TimeseriesSpec,
    TopRow,
    TopSpec,
)

log = logging.getLogger("platform_monitoring.query")


class QueryService:
    """Unified read interface for the monitoring API router.

    - overview: ClickHouse for history + Redis for live requests_1m + unique_ips_hll
    - all other queries: delegate to EventSink (ClickHouseSink)
    """

    def __init__(self, *, sink: EventSink, hot: HotStore) -> None:
        self._sink = sink
        self._hot = hot

    async def overview(self, spec: OverviewSpec) -> OverviewResult:
        base = await self._sink.query_overview(spec)

        # Enrich with Redis hot reads (best-effort; errors return 0)
        requests_1m = 0
        unique_ips_hll = 0
        try:
            minute = int(time.time()) // 60
            requests_1m = await self._hot.window_count("all", "all", 60)
            hll_key = f"mon:hll:uniq:{minute}"
            unique_ips_hll = await self._hot._r.pfcount(hll_key)  # type: ignore[attr-defined]
        except Exception:
            log.debug("Redis hot read failed in overview; using 0 for live fields", exc_info=True)

        return base.model_copy(
            update={
                "requests_1m": requests_1m,
                "unique_ips_hll": unique_ips_hll,
            }
        )

    async def timeseries(self, spec: TimeseriesSpec) -> list[Point]:
        return await self._sink.query_timeseries(spec)

    async def top(self, spec: TopSpec) -> list[TopRow]:
        return await self._sink.query_top(spec)

    async def geo(self, spec: GeoSpec) -> list[GeoBucket]:
        return await self._sink.query_geo(spec)

    async def requests(self, filt: RequestFilter) -> Page[RequestRow]:
        return await self._sink.query_requests(filt)

    async def actor(self, spec: ActorSpec) -> ActorSummary:
        return await self._sink.query_actor(spec)

# src/platform_monitoring/router.py
"""create_monitoring_router — auth-agnostic FastAPI router factory.

The host injects admin_dependency so this library carries no auth assumptions.
All endpoints are READ-ONLY in Phase 1.

Phase-2 deferred (mentioned, not implemented):
  - GET/POST/DELETE /blocks  — denylist CRUD
  - GET/POST /alerts, /alerts/{id}/ack, /alerts/{id}/resolve — alert lifecycle
  - GET/PUT /rules — threshold rule editor
  - WS /ws live feed from Redis (stub present, returns 501 until Phase 2)
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from fastapi import APIRouter, HTTPException, Query

from platform_monitoring.query import QueryService
from platform_monitoring.query_models import (
    ActorSpec,
    ActorTypeFilter,
    GeoSpec,
    Granularity,
    OverviewSpec,
    RequestFilter,
    TimeseriesSpec,
    TopDimension,
    TopSpec,
)

log = logging.getLogger("platform_monitoring.router")


def create_monitoring_router(
    *,
    admin_dependency: Any,
    query_service: QueryService | None = None,
    mcp_stats_provider: Callable[[], Any] | None = None,
    prefix: str = "/v3/monitoring",
) -> APIRouter:
    """Factory for the admin-only monitoring router.

    Args:
        admin_dependency: A FastAPI ``Depends(...)`` expression supplied by the host.
            The library does not check its return value — it just ensures the dep runs.
        query_service: Pre-built QueryService. If None, falls back to the registered
            EventSink + HotStore at request time (useful when registries are set up
            after router creation).
        mcp_stats_provider: Optional async callable ``() -> Any`` that returns MCP
            tool stats from the host's existing data source. If None, /mcp returns 501.
        prefix: URL prefix for all routes (default ``/v3/monitoring``).
    """
    router = APIRouter(prefix=prefix, tags=["monitoring"])

    def _qs() -> QueryService:
        if query_service is not None:
            return query_service
        from platform_monitoring.ports.event_sink import get_event_sink
        from platform_monitoring.ports.hot_store import get_hot_store

        return QueryService(sink=get_event_sink(), hot=get_hot_store())

    # ── GET /overview ─────────────────────────────────────────────────────────
    @router.get("/overview", dependencies=[admin_dependency])
    async def overview(
        from_ts: int = Query(default=..., description="Epoch ms start"),
        to_ts: int = Query(default=..., description="Epoch ms end"),
    ) -> Any:
        spec = OverviewSpec(from_ts=from_ts, to_ts=to_ts)
        result = await _qs().overview(spec)
        return result.model_dump()

    # ── GET /timeseries ───────────────────────────────────────────────────────
    @router.get("/timeseries", dependencies=[admin_dependency])
    async def timeseries(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        granularity: Granularity = Query(default="minute"),
        actor_type: ActorTypeFilter | None = Query(default=None),
        country: str | None = Query(default=None),
        route: str | None = Query(default=None),
    ) -> Any:
        spec = TimeseriesSpec(
            from_ts=from_ts,
            to_ts=to_ts,
            granularity=granularity,
            actor_type=actor_type,
            country=country,
            route=route,
        )
        points = await _qs().timeseries(spec)
        return [p.model_dump() for p in points]

    # ── GET /top ──────────────────────────────────────────────────────────────
    @router.get("/top", dependencies=[admin_dependency])
    async def top(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        dimension: TopDimension = Query(default="ip"),
        limit: int = Query(default=20, ge=1, le=500),
        actor_type: ActorTypeFilter | None = Query(default=None),
    ) -> Any:
        spec = TopSpec(
            from_ts=from_ts, to_ts=to_ts, dimension=dimension, limit=limit, actor_type=actor_type
        )
        rows = await _qs().top(spec)
        return [r.model_dump() for r in rows]

    # ── GET /geo ──────────────────────────────────────────────────────────────
    @router.get("/geo", dependencies=[admin_dependency])
    async def geo(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        limit: int = Query(default=200, ge=1, le=1000),
    ) -> Any:
        spec = GeoSpec(from_ts=from_ts, to_ts=to_ts, limit=limit)
        buckets = await _qs().geo(spec)
        return [b.model_dump() for b in buckets]

    # ── GET /requests ─────────────────────────────────────────────────────────
    # Every row includes request_id (for troubleshooting — see MEMORY.md feedback)
    @router.get("/requests", dependencies=[admin_dependency])
    async def requests(
        from_ts: int = Query(...),
        to_ts: int = Query(...),
        actor_type: ActorTypeFilter | None = Query(default=None),
        country: str | None = Query(default=None),
        route: str | None = Query(default=None),
        ip: str | None = Query(default=None),
        status: int | None = Query(default=None),
        limit: int = Query(default=100, ge=1, le=1000),
        offset: int = Query(default=0, ge=0),
    ) -> Any:
        filt = RequestFilter(
            from_ts=from_ts,
            to_ts=to_ts,
            actor_type=actor_type,
            country=country,
            route=route,
            ip=ip,
            status=status,
            limit=limit,
            offset=offset,
        )
        page = await _qs().requests(filt)
        return page.model_dump()

    # ── GET /actors/{id} ──────────────────────────────────────────────────────
    @router.get("/actors/{actor_id}", dependencies=[admin_dependency])
    async def actor(
        actor_id: str,
        actor_type: ActorTypeFilter = Query(...),
        from_ts: int = Query(...),
        to_ts: int = Query(...),
    ) -> Any:
        spec = ActorSpec(actor_type=actor_type, actor_id=actor_id, from_ts=from_ts, to_ts=to_ts)
        summary = await _qs().actor(spec)
        return summary.model_dump()

    # ── GET /mcp ──────────────────────────────────────────────────────────────
    @router.get("/mcp", dependencies=[admin_dependency])
    async def mcp() -> Any:
        if mcp_stats_provider is None:
            raise HTTPException(
                status_code=501,
                detail="mcp_stats_provider not configured. "
                "Pass mcp_stats_provider= to create_monitoring_router().",
            )
        return await mcp_stats_provider()

    # ── WS /ws — Phase-2 stub ─────────────────────────────────────────────────
    # TODO(phase-2): Implement WebSocket live feed from Redis Stream mon:events
    # and mon:alerts:stream. Consumer reads with XREAD and fans out to connected clients.
    # For now returns 501 via HTTP so the router is registered and doesn't 404.
    @router.get("/ws", dependencies=[admin_dependency], include_in_schema=False)
    async def ws_stub() -> Any:
        raise HTTPException(
            status_code=501,
            detail="WebSocket live feed deferred to Phase 2. "
            "Connect via ws://.../v3/monitoring/ws (not yet active).",
        )

    # ── Phase-2 stubs: /blocks, /alerts, /rules ───────────────────────────────
    # These endpoints are deferred. They are intentionally NOT registered here
    # so the client receives 404 (not 501) — a clear "not yet" signal.
    # When Phase 2 is implemented, add them here with the denylist/alert HotStore methods.

    return router

# src/platform_monitoring/__init__.py
"""platform-monitoring: reusable activity / abuse / usage monitoring."""

from platform_monitoring.alert_delivery import AlertDelivery, LogOnlyDelivery, WebhookDelivery
from platform_monitoring.envelope import Actor, Geo, MonitoringEvent
from platform_monitoring.identity import identify_actor
from platform_monitoring.middleware import MonitoringMiddleware, resolve_client_ip
from platform_monitoring.models import Alert, Block, Rule
from platform_monitoring.query import QueryService
from platform_monitoring.query_models import (
    ActorSpec,
    GeoSpec,
    OverviewSpec,
    RequestFilter,
    TimeseriesSpec,
    TopSpec,
)
from platform_monitoring.router import create_monitoring_router
from platform_monitoring.rule_engine import RuleEngine
from platform_monitoring.settings import MonitoringSettings
from platform_monitoring.worker import IngestionWorker

__version__ = "0.2.0"

__all__ = [
    "Actor",
    "Geo",
    "MonitoringEvent",
    "MonitoringSettings",
    "IngestionWorker",
    "identify_actor",
    "MonitoringMiddleware",
    "resolve_client_ip",
    "QueryService",
    "OverviewSpec",
    "TimeseriesSpec",
    "TopSpec",
    "GeoSpec",
    "RequestFilter",
    "ActorSpec",
    "create_monitoring_router",
    "Block",
    "Rule",
    "Alert",
    "RuleEngine",
    "AlertDelivery",
    "LogOnlyDelivery",
    "WebhookDelivery",
    "__version__",
]
